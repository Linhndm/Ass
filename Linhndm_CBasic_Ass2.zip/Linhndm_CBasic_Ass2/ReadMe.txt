/***********************************************************************************************************************
 *Author: Linhndm
 *Date Modifed: 14/06/2017 12:55 am
 *Name: Linhndm_CBasic_Ass2
 **********************************************************************************************************************/

1> Program help you enter two matrix and return Multiple of us.

2> I cann't use global variable beacause i will use us to embedded system.

3> In my class, you want me check if row of matrix is equal to columns of matrix but matrix 1x1 cann't Multiply it. You 
can only mutiply to any matrix with Identity matrix.

4> In my code, I have written three function help me Check condition and Multiply two matrix.


/Function1*************************************************************************************************************/
/*
Function : int Check(float row, float columns)
    @brief: Check matrix with rows and colomns. If rows or columns is a Positive or Integer Fun will return 0;
                + row: rows of matrix
                + col: columns of matrix
    @return: 
                + True or False
*/

/Function2*************************************************************************************************************/
/*
Function : float* Multiple(float matrix1[], float matrix2[], int rowa, int cola, int rowb, int colb)
    @brief: Multiple two matrices
    @param:     
                + matrix1[]
                + matrix2[]
                + rowa: rows of matrix a
                + cola: columns of matrix a
                + rowb: rows of matrix b
                + colb: columns of matrix b
                + i, j, k: count variables
    @return:
                + Poiter matrix3
*/

/Function3*************************************************************************************************************/
/*
Function : void PrintMatrix(float matrix4[], int row, int col)
    @brief: Print matrix
    @param:
                + row: rows of matrix
                + col: columns of matrix
                + i,j: count variables
    
*/

