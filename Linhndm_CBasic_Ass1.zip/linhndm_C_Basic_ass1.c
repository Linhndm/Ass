#include <stdio.h>

/*******************************************************************************
 * Variables
 ******************************************************************************/
int TOTAL_NUMBER_ARRAY;
int array[20];
int sum = 0;
float AVERAGE_VALUE;
int SMALLER_VALUE = 0;

/*******************************************************************************
 * Prototypes
 ******************************************************************************/
static void s_convert();


/*******************************************************************************
 * Code
 ******************************************************************************/

/* Function for s_convert and arrange: even turn left and odd turn right */
static void s_convert()
{	
	int hand = 0;

	for(int i = 0; i < TOTAL_NUMBER_ARRAY; i++)
	{	
		if( array[i] % 2 == 1)
		{	
			for(int j = i; j  < TOTAL_NUMBER_ARRAY ; j++)
			{	
				if(array[j] % 2 == 0)
				{
					hand = array[i];
					array[i] = array[j];
					array[j] = hand;
				}				
			}
		}		
	}
}

/* Main */
int main()
{	
	
	while (1)
	{
		printf("How many numbers do you want to enter?:  ");
		scanf("%d", &TOTAL_NUMBER_ARRAY);
		if (TOTAL_NUMBER_ARRAY <= 20)
		{			
			printf("Please enter your number: \n");

			/*Caculate Summation of Array*/
			for (int i = 0; i < TOTAL_NUMBER_ARRAY; i++)
			{				
				printf("Number %d = ", i+1);
				scanf("%d", &array[i]);
				sum = sum + array[i];
			} 
			AVERAGE_VALUE = 1.0 * sum / TOTAL_NUMBER_ARRAY;

			/*Calutate Total number  smaller than avenrage val*/
			for(int i = 0; i < TOTAL_NUMBER_ARRAY; i++)
			{
				if (array[i] < AVERAGE_VALUE)
				{
					SMALLER_VALUE = SMALLER_VALUE + 1;
				}
			}

			/*Use function*/
			s_convert();

			/*Print to screen*/
			printf("Avenrage value of array: %f \n", AVERAGE_VALUE );
			printf("Total number smaller than avenrage value: %d \n", SMALLER_VALUE);
			printf("Array after arrange: \n")
			for(int i = 0; i < TOTAL_NUMBER_ARRAY; i++)
			{
				printf("%d\t", array[i]);
			}
			printf("\n");
		}	
		
		else{
			printf("Your can use with under 20 number \n");
		}
	}
	return 0;

}


