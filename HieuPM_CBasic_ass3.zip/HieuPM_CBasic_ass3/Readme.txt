/***********************************************************************************************************************
 *Author: HieuPM
 *Date Modifed: 15/06/2017 7:00PM
 *Name: HieuPM_CBasic_ass4
 **********************************************************************************************************************/
This program help u multiply and add 2 matrix if posible


/Function1*************************************************************************************************************/
/*
Function : int Side(float diag, float peri)
    @brief: Find the side of the rectangle if posible
                + diag: diagonal of the rectangle
                + perimeter of the rectangle
    @return: 
                + 0 - the input valid
                + 1 - the input invalid
*/
/Function2*************************************************************************************************************/
/*
Function : int Solve(float a,float b,float c)
    @brief: Solve the quardatic function
                + float a - a parameter
                + float b - b parameter
                + float c - c parameter
    @return: 
                + 0 - the input valid need further check
                + 1 - the input invalid
*/
/Function3*************************************************************************************************************/
/*
Function : int Negative(float diag,float peri)
    @brief: Check if user enter a negative or decimal number
                + float diag - diagonal of the rectangle
                + float peri - perimeter of the rectangle
    @return: 
                + 0 - the input valid need further check
                + 1 - the input invalid
*/
