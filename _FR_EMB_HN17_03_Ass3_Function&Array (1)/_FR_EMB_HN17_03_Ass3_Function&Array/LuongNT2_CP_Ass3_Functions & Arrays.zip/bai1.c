#include<stdio.h>
#include<stdint.h>
#include<math.h>

/* Prototypes
 ******************************************************************************/
void acreage(float per,float dia);
 /*******************************************************************************
 * Code
 ******************************************************************************/
int main()
{
    float acr;
    float per,dia;
    do
    {
        /*Put the input value*/
        printf("\nEnter the circumference of the rectangle: ");
        scanf("%f",&per);
        printf("\nEnter the diagonal of the rectangle :");
        scanf("%f",&dia);
        /*
        Check input conditions.
            The correct condition is:
                +Measurement must be positive
                + Diagonals must be less than half the rectangular perimeter
                + Diagonal must be greater than the circumference / square root of 8
        If the condition is wrong, end and loop condition check
        */
        if(dia<per/2& dia>sqrt(per*per/8))
        {
            acreage(per,dia);
        }
        else 
        {
            printf("\nInvalid variable, please re-enter");
        }
    }
    /*Check the condition so that it is rectangular and the end of the program*/
    while(dia>=per/2||dia<=sqrt(per*per/8) );
    return 0;
}

/*
Function : void acreage(float per,float dia)
    @brief: Find the area of a rectangle
    @param:
                + per: Perimeter rectangle
                + dia: Diagonal rectangle
                + i,j: count variables
    
*/
void acreage(float per,float dia)
{
    float acr;
    acr=((per*per)/4-dia*dia)/2;
    printf("\nAcreage : %f",acr);
}

