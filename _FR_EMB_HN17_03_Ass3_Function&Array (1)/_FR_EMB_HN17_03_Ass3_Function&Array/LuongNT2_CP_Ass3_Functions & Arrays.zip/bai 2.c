#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#define MAX 100
/***********************************************************************************************************************
 *Prototypes
 **********************************************************************************************************************/
void inputMatrix(float A[],int column,int row);
void productMatrix(float A[], float B[], int rowa, int cola, int rowb, int colb);
void printMatrix(float C[], int row1, int column2);
void totalMatrix(float A[],int column1,int row1,float B[]);
int check(int column1,int row1,int column2,int row2);
/***********************************************************************************************************************
 *Code
 **********************************************************************************************************************/
int main()
{  
    /*Variable local */
    int tempCheck;
    float row11, column11, row21, column21;
    int row1, column1, row2, column2;
    float A[MAX];
    float B[MAX];
    int i,j=0;
    /*Do-while loop, if a re-entry error is required*/
    do
    {
        /*Input matrix information*/
        printf("Enter the number of rows in matrix 1 :");
        scanf("%f",&row11);
        printf("\nEnter the number of columns in matrix 1 :");
        scanf("%f",&column11);
        printf("\nEnter the number of rows in matrix 2 :");
        scanf("%f",&row21);
        printf("\nEnter the number of columns in matrix 2 :");
        scanf("%f",&column21);
        /*Check, if input is a decimal, require re-entering*/
        if(row11!=(int)row11||column11!=(int)column11||row21!=(int)row21||column21!=(int)column21)
        {
            printf("\nRe-Enter : \n*Input numbers must be positive integers*\n");
        }
        else
        {
        	/*Returns the value type for input as 'int'*/
            row1=(int)row11;
            column1=(int)column11;
            row2=(int)row21;
            column2=(int)column21;
            tempCheck=check(row1,column1,row2,column2);
            /*Conditional analysis by "check"*/
            if(tempCheck==1)
            {
                printf("\nPlease enter your information again,value of row and column must be positive:\n");
            }
            else
            {
                if(tempCheck==0)
                {
                    printf("\nTwo matrices are not added together and can not be multiplied\n");
                    printf("\nPlease enter your information again(row1 =column2) :\n");
                }
                else
                /* Satisfactory conditions, enter information and calculate */
                {
                    printf("Input Matrix 1 :\n");
                    inputMatrix(A,column1,row1);
                    printf("\nMatrix 1:\n");
                    printMatrix(A,column1,row1);
                    printf("\nInput Matrix 2 :\n");
                    inputMatrix(B,column2,row2);
                    /*Case :
                    *Two matrices multiply only
					*/
                    if(tempCheck==2)
                    {
                        printf("Matrix (1) x Matrix (2)");
                        productMatrix(A, B, row1, column1, row2, column2);
                    }
                    else
                    {
                        /*Case:
                        *Two matrices are only added together
                        */
                        if(tempCheck==3)
                        {
                            printf("Matrix (1) + Matrix (2)");
                            totalMatrix(A,column1,row1,B);
                        }
                        else
                        {
                            /*Case:
                            *Two square matrices of the same size
                            */
                            if(tempCheck==4)
                            {
                                printf("Matrix (1) + Matrix (2)");
                                totalMatrix(A,column1,row1,B);
                                printf("\nMatrix (1) x Matrix (2)");
                                productMatrix(A, B, row1, column1, row2, column2);
                                break;
                            }
                            else
                            {
                                /*Case :
                                *Two matrices can turn the position then multiply
                                */
                                if(tempCheck==5)
                                {
                                    printf("Matrix (2) x Matrix (1)");
                                    productMatrix(B, A, row2, column2, row1, column1);
                                    break;	
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    /*If the condition is wrong or not multiply, re-enter the value*/
    while(tempCheck!=2&&(tempCheck!=3));
    printf("\n\n\n************   FINISH     ************");
    getch();
    return 0;
}

/*
Function :  productMatrix(float A[], float B[], int rowa, int cola, int rowb, int colb)
    @brief: Matrix multiplication function
    @param:
                + rowa:  rows of matrix A
                + cola:  columns of matrix A
                + rowb:  rows of matrix B
                + colb:  columns of matrix B
                + i,j,k: count variables
                +C[MAX]: Result matrix

*/
void productMatrix(float A[], float B[], int rowa, int cola, int rowb, int colb)
{
    int i, j, k;
    float C[MAX];
    /*Convert matrix to one-dimensional array*/
    for(i=0; i<(rowa); i++)
    {
        printf("\n");
        for(j=0; j<(colb); j++)
        {
            C[i *(rowa)+j]=0;
            /*Calculate the value of each element*/
            for(k=0; k<(cola); k++)
            {
                /*When the matrix is down one row, the corresponding address on the array increases to a value =rowa*/
                C[ i * (rowa) + j ] += A[ i * (rowa) + k ] * B[ k * (colb) + j];
            }
            printf("%2.f   ",C[i *(colb)+j]);
        }
    }
}
/*
Function : printMatrix(float C[], int row, int column)
    @brief: Function print matrix to screen
    @param:
                + row:    rows of matrix
                + column: columns of matrix
                + i,j:    count variables
    
*/
void printMatrix(float C[], int row, int column)
{
    int i, j;
    /*Convert matrix to one-dimensional array*/
    for(i = 0; i< row; i++)
    {
        printf("\n\t\t\t");
        for(j = 0; j < column; j++)
        {
            printf("%.2f  ", C[ i * (column) + j ]);
       }
    }
}

/*
Function : check(int col1,int row1,int col2,int row2)
    @brief: Check condition
    @param:     
                + col1:  column of matrix1
                + row1:     row of matrix1
                + col2:  column of matrix2
                + row2:     row of matrix 2
    @return:
                + Value for condition check
*/
int check(int col1,int row1,int col2,int row2)
{
    /* Input value is negative: False */
    if((row1<=0)||(col1<=0)||(row2<=0)||(row2<=0))
    {
        return 1;
    }
    else
    {
        /*Matrix of same size, Can be added together*/
        if((col1==col2)&&(row1==row2)&&(col1!=row1))
        {
        return 3;
        }
        else
        {
            /*Matrix can multiply*/
            if((col1==row2)&((col1!=row1)||(col2!=row2)))
            {
                return 2;
            }
            else
            {
                /*Two square matrices are also sized*/
                if(col1==col2&row1==row2&col1==row1)
                {
                    return 4;
                }
                else 
                {
                    /*Two matrices can be multiplied by the island position*/
                    if((col2==row1)&((col2!=row2)||(col1!=row1)))
                    {
                        return 5;
                    }
                    else
                    {
                        return 0;
                    }
                }
            }
        }
    }
}

/*
Function : totalMatrix(float A[],int column1,int row1,float B[])
    @brief: Total 2 matrices
    @param:
                + row1: rows of matrix1,2
                + col1: columns of matrix1,2
                + a,b: count variables
                total[MAX]:Total matrix,count variables
    
*/
void totalMatrix(float A[],int column1,int row1,float B[])
{
    float total[MAX];
    int a,b;
    for(a=0;a<column1;a++)
    {
        printf("\n");
        for(b=0;b<row1;b++)
        {
            /*From one dimensional array printed matrix*/
            total[a*column1 +b]=A[a*column1 +b]+B[a*column1 +b];
            printf("%2.f ;",total[a*column1 +b]);
        }
    }
}

/*
Function : inputMatrix(float A[],int column,int row)
    @brief: Input Matrix
    @param:
                + row: rows of matrix
                + col: columns of matrix
                + a,b,temp: count variables
    
*/
void inputMatrix(float A[],int column,int row)
{
    int a,b,temp;
    for(a=0;a<column;a++)
    {
        for(b=0;b<row;b++)
        {
            printf("Enter the element value [%d ,%d]",a+1,b+1);
            scanf("%d",&temp);
            A[a*column+b]=temp;
        }
    }
}


