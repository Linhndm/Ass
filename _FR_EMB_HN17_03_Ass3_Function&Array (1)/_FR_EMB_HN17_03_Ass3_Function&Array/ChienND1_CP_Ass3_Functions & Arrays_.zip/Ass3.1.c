#include <stdio.h>
#include <stdlib.h>
/*******************************************************************************
 * Prototypes
 ******************************************************************************/
/*************************************************************
-Function : check enter input

-Parameter: the perimeter and diagonal of rectangle

-Return : 0 or 1
*************************************************************/
int Check(float peri, float diag);
/*******************************************************************************
 * Code
 ******************************************************************************/
int main()
{
    /*Initialize the perimeter and diagonal*/
    float peri, diag;
    /*Initialize test Variable*/
    int check;
    /*Assign that variable on 1*/
    check=1;
    while (check==1)
    {
        printf("Enter Perimeter:");
        scanf("%f",&peri);
        printf("Enter Diagonal: ");
        scanf("%f",&diag);
        /*Assign variable check to Check function*/
        check = Check(peri,diag);
        if(check==1)
        {
            printf("Area rectangle : %.3f",(float) (peri*peri/8-diag*diag/2));
            getch();
        }
        else
        {
            printf("You enter fail.");
            getch();
        }
        printf("\nYou want enter?\nEnter number 1 if you want re-enter\nEnter any key to exit ");
        scanf("%d",&check);  
    }
    return 0;
}
int Check(float peri, float diag)
{
    /*Satisfying conditions return 1, does not return 0*/
    if(peri>0&&diag>0&&((diag*diag-((peri*peri)/8))>=0)&&peri>2*diag)
    {
        return 1;
    }
    else
    {
        return 0;
    }
};
