#include <stdio.h>
#include <stdlib.h>

#define MAX_ROW 100
#define MAX_COL 100

/*******************************************************************************
 * Prototypes
 ******************************************************************************/
/*************************************************************

-Function : check input

-Parameter: the number of row and column of matrix

-Return : 0 or 1

*************************************************************/
int checkInput(int row1, int col1, int row2, int col2);
/*************************************************************

-Function : Input data for matrix

-Parameter: matrix,the number of row and column

-Return : void

*************************************************************/
void inputMatrix(int row, int col,  int Arr[row][col]);
/*************************************************************
-Function : display matrix on screen

-Parameter: matrix, and the number of row and column

-Return : void

*************************************************************/
void OutputMatrix(int row, int col, int Arr[row][col]);
/*************************************************************

-Function : check 2 matrix are Multi

-Parameter: the number of row and column of matrix

-Return : int: 0, 1, 2, 3

*************************************************************/
int checkMulti(int row1, int col1, int row2, int col2);
/*************************************************************

-Function : check 2 matrix are Addition

-Parameter: the number of row and column of matrix

-Return : int: 0 or 1

*************************************************************/
int checkSum(int row1, int col1, int row2, int col2);
/*************************************************************

-Function : Multiplication 2 matrix

-Parameter: 2 matrix, and the number of row and column

-Return : void

- contains result

*************************************************************/
void funcMulti1x2(int row1, int col1, int row2, int col2, int A[row1][col1],int B[row2][col2]);
/*************************************************************

-Function : Multiplication 2 matrix

-Parameter: 2 matrix, and the number of row and column

-Return : void

- contains result

*************************************************************/
void funcMulti2x1(int row1, int col1, int row2, int col2, int A[row1][col1],int B[row2][col2]);
/*************************************************************

-Function : Addition 2 matrix

-Parameter: 2 matrix, and the number of row and column

-Return : void

- contains result

*************************************************************/
void Sum(int row1, int col1, int row2, int col2, int A[row1][col1],int B[row2][col2]);
/*******************************************************************************
 * Code
 ******************************************************************************/
int main()
{
    /*Initialize the number of row, column and matrix*/
    int row1, col1, row2, col2, A[row1][col1], B[row2][col2];
    printf("Enter Matrix row 1: ");
    scanf("%d",&row1);
    printf("Enter Matrix column 1: ");
    scanf("%d",&col1);
    printf("Enter Matrix row 2: ");
    scanf("%d",&row2);
    printf("Enter Matrix column 2: ");
    scanf("%d",&col2);
    /*Initialize variable test*/
    int checkinput, checkmulti, checksum;
    checkinput=CheckInput(row1, col1, row2, col2);
    if(checkinput==1)
    {
        printf("Value Matrix 1:\n");
        /*Call the function import matrix value*/
        inputMatrix(row1,col1, A);
        printf("Value Matrix 2:\n");
        /*Call the function import matrix value*/
        inputMatrix(row2,col2, B);
        printf("Matrix 1:\n");
        /*Call the function Export matrix value*/
        OutputMatrix(row1,col1,A);
        printf("Matrix 2:\n");
        /*Call the function Export matrix value*/
        OutputMatrix(row2,col2,B);
        checkmulti=checkMulti(row1, col1, row2, col2);
        switch(checkmulti)
       {
            case 1:
            {
                printf("Multi both aways:\n");
                funcMulti1x2(row1, col1, row2, col2, A, B);
                funcMulti2x1(row1, col1, row2, col2, A,B);
                break;
            }
            case 2:
            {
                printf("Multi Matrix 1x2:\n");
                funcMulti1x2(row1, col1, row2, col2, A,B);
                break; 
            }
            case 3:
            {
                printf("Multi Matrix 1x2:\n");
                funcMulti2x1(row1, col1, row2, col2, A, B);
                break; 
            }
            default:
            {
                printf("Can not Multiplication 2 matrix\n");
            }
        }
        checksum=checkSum(row1, col1, row2, col2);
        if(checksum==1)
        {
            Sum(row1,col1,row2,col2,A,B);
            printf("\n");
        }
        else
        {
            printf("Can not summation 2 matrix.");
        }
    }
    else
    {
        printf("You entered the wrong input");
    }
        return 0;
}
void inputMatrix(int row, int col,  int MTrix[row][col])
{
    /*Initialize variables number count*/
    int var1, var2;
    /*Enter value of Matrix*/
    for(var1=0;var1<row;var1++)
    {
        for(var2=0;var2<col;var2++)
        {
            printf("MTrix[%d,%d]=",var1,var2);
            scanf("%d",&MTrix[var1][var2]);
        }
    }
    printf("\n");
};
void OutputMatrix(int row, int col, int MTrix[row][col])
{
    /*Initialize variables number count*/
    int var1, var2;
    /*Display matrix on screen*/
    for(var1=0;var1<row;var1++)
    {
        for(var2=0;var2<col;var2++)
        {
            printf("%d ",MTrix[var1][var2]);
        }
        printf("\n");
    }
};
int CheckInput(int row1, int col1, int row2, int col2)
{
    /*The row and column of Matrix is positive return 1, not positive return 0*/
    if(row1>0&&col1>0&&row2>0&&col2>0)
    {
        return 1;
    }
    else
    {
        return 0;
    }
};
int checkMulti(int row1, int col1, int row2, int col2)
{
    /*Check row and column of Matrix and return 0, 1, 2, 3*/
    if (col1==row2&&col2==row1)
    {
        /*Column Matrix 1 = row Matrix 2 and column matrix 2 = row matrix 1 is return 1*/
        return 1;
    }
    else
    {
        if(col1==row2&&col2!=row1)
        /*Column Matrix 1 equal row Matrix 2 and column matrix 2 different row matrix 1 is return 2*/
        {
            return 2;
        }
        else
        {
            if (col1!=row2&&col2==row1)
            /*Column Matrix 1 different row Matrix 2 and column matrix 2 equal row matrix 1 is return 3*/
            {
                return 3;
            }
            else
            {
                return 0;
            }
        }
    }
};
int checkSum(int row1, int col1, int row2, int col2)
{
    /*Row Matrix 1 equal row Matrix 2 and column matrix 1 equal column matrix 2 is return 1*/
    if(row1==row2&&col1==col2)
    {
        return 1;
    }
    else
    {
        return 0;
    }
};
void funcMulti1x2(int row1, int col1, int row2, int col2, int A[row1][col1],int B[row2][col2])
{
    /*Initialize Array and variables number count*/
    int C[row1][col2];
    int var1, var2, var3;
    /*Calculate the result of multiplication 2 matrixs*/
    for (var1=0;var1<row1;var1++)
        {
            for (var2=0;var2<col2;var2++)
            {
                C[var1][var2]=0;
                for(var3=0;var3<row2;var3++)
                {
                    C[var1][var2]+=A[var1][var3]*B[var3][var2];
                }
            }
        }
    printf("Multiplication Matrix 1x2:\n");
    /*Print matrix after Multiplication on screen*/
    for (var1=0;var1<row1;var1++)
    {
        for (var2=0;var2<col2;var2++)
        {
            printf("%d\t",C[var1][var2]);
        }
        printf ("\n");
    }
};
void funcMulti2x1(int row1, int col1, int row2, int col2, int A[row1][col1],int B[row2][col2])
{
    /*Initialize Array and variables number count*/
    int C[row2][col1];
    int var1, var2, var3;
    /*Calculate the result of multiplication 2 matrixs*/
    for (var1=0;var1<row2;var1++)
        {
         for (var2=0;var2<col1;var2++)
            {
                C[var1][var2]=0;
                for(var3=0;var3<row1;var3++)
                {
                     C[var1][var2]+=B[var1][var3]*A[var3][var2];
                }
            }
        }
    printf("Multiplication Matrix 2x1:\n");
    /*Print matrix after Multiplication on screen*/
    for (var1=0;var1<row2;var1++)
    {
        for (var2=0;var2<col1;var2++)
        {
            printf("%d\t",C[var1][var2]);
        }
        printf ("\n");
    }
};
void Sum(int row1, int col1, int row2, int col2, int A[row1][col1],int B[row2][col2])
{
    /*Initialize Array and variables number count*/
    int C[row1][col1];
    int var1, var2, var3;
    /*Calculate the result of multiplication 2 matrixs*/
    for (var1=0;var1<row1; var1++)
    {
        for (var2=0; var2<col1; var2++)
        {
            C[var1][var2]=A[var1][var2]+B[var1][var2];
        }
    }
    printf("Matrix after Addition:\n");
    /*Print matrix after Addition on screen*/
    for (var1=0;var1<row1; var1++)
    {
        for (var2=0; var2<col1; var2++)
        {
            printf ("%d ",C[var1][var2]);
        }
        printf("\n");
    }
};

    
