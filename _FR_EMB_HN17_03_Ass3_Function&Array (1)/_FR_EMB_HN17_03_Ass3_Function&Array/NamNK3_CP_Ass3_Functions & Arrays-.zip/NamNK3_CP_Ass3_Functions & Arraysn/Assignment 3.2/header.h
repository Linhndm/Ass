#ifndef _header_H_
#define _header_H_

/*******************************************************************************
 * Definitions
 ******************************************************************************/
#define MACRO2 2

/*******************************************************************************
 * API
 ******************************************************************************/
 
/*
 * @ brief <Enter Area of rectangle, know Perimeter and Diagonal line>
 * @author: NamNK3
 * @purpose: Assignment 3.2.
*/

/*Function void matrix_input(int x, int y, int a[x][y]);
 * @brief: input matrix
 * @input x: row matrix
          y: column matrix
          a[x][y]: Matrix A
 * @return <None >.
*/
void matrix_input(int x, int y, int a[x][y]);

/*Function display(int x,int y,int a[x][y]);
 * @brief: display matrix
 * @input x: row matrix
          y: column matrix
          a[x][y]: Matrix A
 * @return <None >.
*/
void display(int x,int y,int a[x][y]);

/*Function check_sum(int x,int y, int z,int t, int a[x][y],int b[z][t]);
 * @brief: Check condition for total the matrix
 * @input x: row matrix A
          y: column matrix A
          z: row matrix B
          t: column matrix B
          a[x][y]: Matrix A input
          b[z][t]: Matrix B input
 * @return <None >.
*/
void check_sum(int x,int y, int z,int t, int a[x][y],int b[z][t]);

/*Function sum_matrix(int x, int y, int a[x][y],int b[x][y]);
 * @brief: Total the matrix A+B
 * @input x: row matrix
          y: column matrix
          a[x][y]: Matrix A
          b[x][y]: Matrix B
 * @return <None >.
 */
void sum_matrix(int x, int y, int a[x][y],int b[x][y]);

/*Function multi_matrix(int x, int y, int t, int a[x][y], int b[y][t]);
 * @brief: Multiplication matrix A+B
 * @input x: row matrix A
          y: column matrix A = row matrix B
          t: column matrix B
          a[x][y]: Matrix A
          b[y][t]: Matrix B
 * @return <None >.
 */
void multi_matrix(int x, int y, int t, int a[x][y], int b[y][t]);

/*Function check_multi(int x, int y, int z,int t, int a[x][y], int b[z][t]);
 * @brief: Check conditions for matrix multiplication
 * @input x: row matrix A
          y: column matrix A
          z: row matrix B
          t: column matrix B
          a[x][y]: Matrix A input
          b[z][t]: Matrix B input
 * @return <None >.
*/
void check_multi(int x, int y, int z,int t, int a[x][y], int b[z][t]);

/*Function check(int x, int y, int z,int t, int a[x][y], int b[z][t]);
 * @brief: Check the conditions for two matrixes plus / multiply together
 * @input x: row matrix A
          y: column matrix A
          z: row matrix B
          t: column matrix B
          a[x][y]: Matrix A input
          b[z][t]: Matrix B input
 * @return <None >.
*/
void check(int x, int y, int z,int t, int a[x][y], int b[z][t]);

#endif /* _header_H_ */

