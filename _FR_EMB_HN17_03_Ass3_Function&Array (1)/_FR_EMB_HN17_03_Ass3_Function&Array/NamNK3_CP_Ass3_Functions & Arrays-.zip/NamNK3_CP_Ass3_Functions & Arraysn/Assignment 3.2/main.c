#include <stdio.h>
#include <stdlib.h>
#include "header.h"
#include <stdint.h>

/*Declare functions to use in header.h file*/
void matrix_input();
void display();
void check_sum();
void sum_matrix();
void multi_matrix();
void check_multi();
void check();

/* Code main*/
void main() {
    int x,y,z,t;/*Declare row number and column number of 2 matrix*/
    int a[x][y],b[z][t];/*Declare 2 matrix A, B*/

    printf("Enter matrix size A: \n");
    do
    {
        printf("Row input A: ");
        scanf("%d",&x);/*Enter the row number of A*/
        printf("Column input A: ");
        scanf("%d",&y);/*Enter the row number of A*/
        if(x<=0||y<=0)/*Check if not satisfied, print the text*/
        {
            printf("Fail-Enter again! \n");/**/
        }
    }
    while(x<=0||y<=0);/*Repeat the command until the condition is not satisfied*/
    matrix_input(x,y,a);

    printf("Enter matrix size B: \n");
    do
    {
        printf("Row input B: ");
        scanf("%d",&z);/*nter the row number of B*/
        printf("Column input B: ");
        scanf("%d",&t);/*Enter the row number of B*/
        if(z<=0||t<=0)/*Check if not satisfied, print the text*/
        {
            printf("Fail-Enter again! \n");
        }
    }
    while(z<=0||t<=0);/*Repeat the command until the condition is not satisfied*/
    matrix_input(z,t,b);

    printf("Matrix A\n");
    display(x,y,a);/*Display matrix A*/
    
    printf("Matrix B\n");
    display(z,t,b);/*Display matrix B*/

    check(x,y,z,t,a,b);/*Check to multiply / add 2 matrix*/

    printf("Total matrix\n");
    check_sum(x,y,z,t,a,b);/*Check and execute plus 2 matrix*/

    printf("Area of 2 matrix A*B\n");
    check_multi(x,y,z,t,a,b);/*Examine and execute two multipliers in A * B*/

    printf("Area of 2 matrix B*A\n");
    check_multi(z,t,x,y,b,a);/*Examine and execute the matrix multiplication in reverse B * A*/
}
