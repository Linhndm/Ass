#include <stdio.h>
#include <stdlib.h>

void matrix_input(int x, int y, int a[x][y])
{
    int i,j;/*Declaring loop variables*/
    /*The loop validates the values in the matrix*/
    for(i=0;i<x;i++)
    {
        for(j=0;j<y;j++)
        {
            printf("a[%d][%d]=",i,j);/*Print out the names of each element of the matrix*/
            scanf("%d",&a[i][j]);/*Enter the value of each element of the matrix*/
        }
    }
}

void display(int x,int y,int a[x][y])
{
    int i,j;/*Declaring loop variables*/
    /*Loop cage for printing matrix*/
    for(i=0;i<x;i++)
    {
        for(j=0;j<y;j++)
        {
            printf(" %d ",a[i][j]);/*Print out each element of the matrix*/
        }
        printf("\n");
    }
}

void check_sum(int x,int y, int z,int t, int a[x][y],int b[z][t])
{
    if (x==z&&y==t)/*Conditional check row and column 2 matrix*/
    {
        sum_matrix(x,y,a,b);/*Satisfying the call to the function sum_matrix*/
    }
    else
    {
        printf("Can not add these two matrix!\n");/*Reverse print the text */
    }
}

int sum_matrix(int x, int y, int a[x][y],int b[x][y])
{
    int i,j;/*Declaring loop variables*/
    int total[x][y];/*Declare the total matrix*/
    for(i=0;i<x;i++)
    {
        for(j=0;j<y;j++)
        {
            total[i][j]=a[i][j]+b[i][j];/*Find each element of the total matrix*/
        }
    }
    display(x,y,total);/*Display total matrix*/
}

void multi_matrix(int x, int y, int t, int a[x][y], int b[y][t])
{
    int i,j,k;/*Declaring loop variables*/
    int multi[x][t];/*Multiplication matrix declaration*/
    for(i=0;i<x;i++)
    {
        for(j=0;j<t;j++)
        {
            int sum=0;
            for(k=0;k<y;k++)
            {
                sum=sum+a[i][k]*b[k][j];/*The sum of the elements multiplied from the first matrix row to the second matrix column respectively*/
            }
            multi[i][j]=sum;/*Each result of the above sum is one element of the multiplication matrix*/
        }
    }
    display(x,t,multi);/*Display multiplication matrix*/
}
void check_multi(int x, int y, int z,int t, int a[x][y], int b[z][t])
{
    if(y==z)/*Check the column number of the first matrix if it is equal to the second row of the matrix*/
    {
        multi_matrix(x,y,t,a,b);/*Make the function call to find the multiplication matrix*/
    }
    else
    {
        printf("It is not possible to multiply these two matrices!\n");/*else,printing the text "can not be"*/
    }
}
void check(int x, int y, int z,int t, int a[x][y], int b[z][t])
{
    if(x==z&&y==t)/*Conditions for calculating the sum of two matrices*/
    {
        printf("Two matrix plus one \n");
        if(z==y)/*If the square matrix is positive and multiply*/
        {
            printf("Two matrix multiply together \n");
        }
    }
    else if(y==z)/*If y = z then multiply*/
    {
        printf("Two matrix multiply together \n");
    }
    else/*The remaining is neither multiplication nor addition*/
    {
        printf("Two matrices can not add up!!!\nTwo matrices can not be multiplied together\n");
    }
}
