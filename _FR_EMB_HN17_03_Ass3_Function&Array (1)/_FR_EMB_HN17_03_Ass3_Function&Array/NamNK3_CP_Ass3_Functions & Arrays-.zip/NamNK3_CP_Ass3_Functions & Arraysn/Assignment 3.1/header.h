#ifndef _header_H_
#define _header_H_

/*******************************************************************************
 * Definitions
 ******************************************************************************/
#define MACRO2 2

/*******************************************************************************
 * API
 ******************************************************************************/
 
/*
 * @ brief <Enter Area of rectangle, know Perimeter and Diagonal line>
 * @author: NamNK3
 * @purpose: Assignment 3.1.
*/

void area (float a, float b);

#endif /* _header_H_ */
