#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <math.h>
#include "header.h"

/*Area function declaration*/
void area (float a, float b);

/*Code main*/
void main ()
{
    float x,y;/*Declare two variables perimeter=x and diagonal=y*/
    do
    {
        /*Enter the perimeter and diagonal of the rectangle*/
        printf("Perimeter input: ");
        scanf("%f",&x);/*Enter the perimeter*/
        printf("Diagonal line input: ");
        scanf("%f",&y);/*Enter the diagonal*/
        if(x<0||y<0||(y*y)>=(x*x)/4||(y*y)<=(x*x)/8)/*Check if the rectangle is not satisfied, then enter the text again*/
        {
            printf("Not rectangles");
            printf("Fail, Enter again! ");
        }
    }
    while(x<0||y<0||(y*y)>=(x*x)/4||(y*y)<=(x*x)/8);/*The unsatisfactory condition is that the rectangle and re-enter it until satisfied, then exit the loop*/
    area(x,y);/*Call the area calculation function after entering the perimeter and diagonal values*/
}