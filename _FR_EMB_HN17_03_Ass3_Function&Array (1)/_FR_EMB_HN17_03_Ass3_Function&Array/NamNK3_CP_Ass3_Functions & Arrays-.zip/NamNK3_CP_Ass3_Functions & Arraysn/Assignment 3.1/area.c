#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <math.h>

/*Function void area (float c, float z);
 * @input <Enter the perimeter and diagonal of the rectangle a,b>
        c:Declare perimeter
        z:Declare diagonal
 * @return <None>.
*/

float area (float c, float z)
{
    float s;/*Declare variable area*/
    if( (z*z) >= (c*c)/8 && (z*z) <= (c*c)/4 )/*Check the condition to be a rectangle*/
    {
        s = ((c*c)/8 - (z*z)/2);/*Find the area of a rectangle*/
        printf("Area of rectangle is: S = %.2f",s);
    }
}