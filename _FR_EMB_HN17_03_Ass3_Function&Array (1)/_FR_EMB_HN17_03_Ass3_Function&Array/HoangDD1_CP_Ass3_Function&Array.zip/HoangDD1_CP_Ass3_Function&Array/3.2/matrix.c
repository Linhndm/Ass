#include "ass3.2.h"

int matrixCheck(int a, int b)
{
    if((a <1)||(b <1)||(a>MAX_SIZE)||(b>MAX_SIZE))
    {
        printf("\nSize must be greater than 0 and smaller than 20");
        return 1;
    }
    else
    {
        return 0;
    }
}

void matrixPrint(float* matrix,int row, int col)
{
    int i, j;
    for(i=0; i< row; ++i)
    {
        for(j=0; j < col; j++)
        {
            printf("    %.1f", matrix[i*col+j]);
        }
        printf("\n");
    }
}

void matrixInput(float* matrix,int row,int col)
{
    int i,j;
    for(i=0; i< row; i++)
    {
        for(j=0; j< col; j++)
        {
            printf("\tElemen[t%d][%d] = ",i+1, j+1);
            scanf("%f", &matrix[i*col+j]);
        }
    }
}