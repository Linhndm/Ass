#ifndef _ASS_3_2_H_
#define _ASS_3_2_H_

#include <stdint.h>
#include <stdio.h>

/*******************************************************************************
 * Definitions
 ******************************************************************************/
#define MAX_SIZE 20

/*******************************************************************************
 * API matrixCheck
 ******************************************************************************/
/*!
 * @brief <Check the size of matrix>
 *
 * @param a <row of matrix>.
 * @param b <column of matrix>.
 *
 * @return <1: invalid size
            0: valid size >.
 */
int matrixCheck(int a, int b);

/*******************************************************************************
 * API matrixPrint
 ******************************************************************************/
/*!
 * @brief <Print matrix's elements>
 *
 * @param matrix <matrix to print>.
 * @param rowr <row of result matrix>.
 * @param colr <column of result matrix>.
 *
 * @return <None>.
 */
void matrixPrint(float* matrix,int row, int col);

/*******************************************************************************
 * API matrixInput
 ******************************************************************************/
/*!
 * @brief <Input elements of matrix>
 *
 * @param matrix <matrix to input>.
 * @param rowr <row of result matrix>.
 * @param colr <column of result matrix>.
 *
 * @return <None>.
 */
void matrixInput(float* matrix,int row,int col);

/*******************************************************************************
 * API calType
 ******************************************************************************/
/*!
 * @brief <Find the case of caculation>
 *
 * @param row1 <row of first matrix>.
 * @param col1 <column of first matrix>.
 * @param row2 <row of second matrix>.  
 * @param col2 <column of second matrix>.
 *
 * @return <0: <2 matrixes can not multiply,add>.
            1: <Same size matrix -> 2 ways of mutiply and addition are possible>.
            2: <2 ways of multiply>.
            3: <matrix 1 x matrix 2>.
            4: <matrix 2 x matrix 1>.
 */
int calType(int row1,int col1,int row2,int col2);

/*******************************************************************************
 * API dispCalType
 ******************************************************************************/
/*!
 * @brief <Print the calculate case to screen>
 *
 * @param type <type of case, defined in calType()>.
 * @param row1 <row of first matrix>.
 * @param col1 <column of first matrix>.
 * @param row2 <row of second matrix>.  
 * @param col2 <column of second matrix>.
 *
 * @return <none>.
 */
void dispCalType(int type,int row1,int col1,int row2,int col2);

/*******************************************************************************
 * API matrixAdd
 ******************************************************************************/
/*!
 * @brief <add 2 matrix entered>
 *
 * @param matrix3: <result array>.
 * @param matrix1,matrix2: < addition's factor>.
 * @param row:  <row of matrix>.
 * @param col: <column of matrix>.
 *
 * @return <none>.
 */
void matrixAdd(float* matrix3,float* matrix1,float* matrix2,int row,int col);

/*******************************************************************************
 * API matrixMultip
 ******************************************************************************/
/*!
 * @brief <Multyply 2 matrix entered>
 *
 * @param matrix3: <result array>.
 * @param matrix1,matrix2: < Multiplition's factor>.
 * @param row:  <row of matrix>.
 * @param col: <column of matrix>.
 * @param cols: <Column of first matrix in multiplication>.
 *
 * @return <none>.
 */
void matrixMulip(float* matrix3,float* matrix1,float* matrix2,int row,int col,int cols);
#endif /*_ASS_3_2_H_*/
