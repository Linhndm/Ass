#include "ass3.2.h"

/*******************************************************************************
 * Code
 ******************************************************************************/
void main()
{
    float matrix1[40],matrix2[40],result[40];
    int row1,col1,row2,col2;
    int i, j, type;
    do
    {
        do
        {
            /*Input size of matrix*/
            do
            {
                printf("\nSize of matrix 1 (ex: 2x3): ");
                scanf("%dx%d", &row1,&col1);
            }
            while (matrixCheck(row1,col1));

            do
            {
                printf("\nSize of matrix 2 (ex: 2x3): ");
                scanf("%dx%d", &row2,&col2);
            }
            while (matrixCheck(row2,col2));

            /*Calculation case*/
            type=calType(row1,col1,row2,col2);
            dispCalType(type,row1,col1,row2,col2);
            if(type==0)
            {
                printf("\n\nReEnter please......\n");
            }
        }
        while(type==0);


        /*Input Elements*/
        printf("\nEnter elements of matrix 1:\n");
        matrixInput(matrix1,row1,col1);
        printf("\nEnter elements of matrix 2:\n");
        matrixInput(matrix2,row2,col2);
        
        /*Calculate and print result to screen*/
        switch(type)
        {
            case 1:     /*Same size*/
            {
                printf("\nResult of Matrix 1 + Matrix 2: \n");
                matrixAdd(result,matrix1,matrix2,row1,col1);
                matrixPrint(result,row1,col1);
                printf("\nResult of Matrix 1 x Matrix 2\n");
                matrixMulip(result,matrix1,matrix2,row1,col2,col1);
                matrixPrint(result,row1,col2);
                if(row1==col1)
                {
                    printf("\nResult of Matrix 2 x Matrix 1\n");
                    matrixMulip(result,matrix2,matrix1,row2,col1,col2);
                    matrixPrint(result,row2,col1);
                }
                break;
            }
            case 2:     /*2 matrixes can multiply by 2 ways*/
            {
                printf("\nResult of Matrix 1 x Matrix 2\n");
                matrixMulip(result,matrix1,matrix2,row1,col2,col1);
                matrixPrint(result,row1,col2);   

                printf("\nResult of Matrix 2 x Matrix 1\n");
                matrixMulip(result,matrix2,matrix1,row2,col1,col2);
                matrixPrint(result,row2,col1);
                break;
            }
            case 3:     /*Matrix 1 x Matrix 2*/
            {
                printf("\nResult of Matrix 1 x Matrix 2\n");
                matrixMulip(result,matrix1,matrix2,row1,col2,col1);
                matrixPrint(result,row1,col2); 
                break;
            }
            case 4:     /*Matrix 2 x Matrix 1*/
            {
                printf("\nResult of Matrix 2 x Matrix 1\n");
                matrixMulip(result,matrix2,matrix1,row2,col1,col2);
                matrixPrint(result,row2,col1);
                break;
            }
        }
        printf("\nPress anykey to try another or ESC to quit....");
        printf("\n**********************************************");
    }
    while(getch()!=27);
}




