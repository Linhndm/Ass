
#include "ass3.2.h"

int calType(int row1,int col1,int row2,int col2)
{
    int type=0;
    if((row1==row2)&&(col1==col2))
    {
        type=1;
    }
    else if((col1==row2)&&(col2==row1))
    {
        type=2;
    }
    else if(col2==row1)
    {
        type=3;
    }
    else if(col2==row1)
    {
        type=4;
    }
    return type;
}

void dispCalType(int type,int row1,int col1,int row2,int col2)
{
    switch(type)
    {
        case 1:
        {
            printf("\n-2 matrix can add each other\n    +Size of resulf matrix: %dx%d",row1,col1);
            printf("\n-2 matrixes can multiply by each other");
            printf("\n    +Size of result matrix: %dx%d",row1,col2);
            break;
        }
        case 2:
        {
            printf("\n-2 matrix can not add each other");
            printf("\n-2 matrixes can multiply by 2 ways,");
            printf("\n    +Size of result matrix: %dx%d and %dx%d",row1,col2,row2,col1);
            break;
        }
        case 3:
        {
            printf("\n-2 matrix can not add each other");
            printf("\n-Matrix 1 can be multiplied by matrix 2");
            printf("\n    +Size of result matrix: %dx%d",row1,col2);
            break;
        }
        case 4:
        {
            printf("\n-2 matrix can not add each other");
            printf("\n-Matrix 2 can be multiplied by matrix 1");
            printf("\n    +Size of result matrix: %dx%d",row2,col1);
            break;
        }
        default:
        {
            printf("\n-2 matrix can not multiply or add each orther");
        }
    }
}


void matrixAdd(float* matrix3,float* matrix1,float* matrix2,int row,int col)
{
    int i=0;
    for(i=0;i<(row*col);i++)
    {
        matrix3[i]=matrix1[i]+matrix2[i];
    }
}

void matrixMulip(float* matrix3,float* matrix1,float* matrix2,int row,int col,int cols)
{
    int i, j, k;
    for(i=0; i<(row); i++)
    {                           
        for(j=0; j<(col); j++)
        {
            float temp=0;
            for(k=0; k<(cols); k++)
            {
                temp+=matrix1[i*(cols)+k]*matrix2[k*(col)+j];
            }
            matrix3[i*(col)+j]=temp;
        }
    }
}
