#include "ass3.1.h"

/*******************************************************************************
 * Variables
 ******************************************************************************/
/*******************************************************************************
 * Code
 
 ******************************************************************************/
int check_rectangle(float peri,float diagon)
{
    if((peri<=0)||(diagon<=0))
    {
        printf("\nthe Perimeter and Diagonal must be greater than 0");
        return 0;
    }
    else if(diagon>=(peri/2)||(diagon<(sqrt(pow(peri,2)/8))))
    {
        printf("\nThe Perimeter and Diagonal entered is not match with a Rectangle");
        return 0;
    }
    else
    {
        return 1;
    }
}

float area_calc(float peri,float diagon)
{
    return ((pow(peri/2,2)-pow(diagon,2))/2);
}

void main()
{
    float peri=0;
    float diagonal=0;
    float area=0;
    do
    {
        printf("\nEnter the Perimeter: ");
        scanf("%f",&peri);
        printf("\nEnter the Diagonal: ");
        scanf("%f",&diagonal);
        if(check_rectangle(peri,diagonal)==1)
        {
            area=area_calc(peri,diagonal);
            printf("\nThe Area of this rectangle: %5.2f",area);
        }
        printf("\nPress anykey to try another one or ESC to quit\n");
    }
    while(getch()!=27);
}

