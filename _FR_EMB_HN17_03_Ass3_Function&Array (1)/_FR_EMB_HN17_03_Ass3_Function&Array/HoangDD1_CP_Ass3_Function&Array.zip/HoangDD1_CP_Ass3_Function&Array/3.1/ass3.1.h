#ifndef _ASS3_1_H_
#define _ASS3_1_H_

#include <stdio.h>
#include <stdint.h>
#include <math.h>
/*******************************************************************************
 * API
 ******************************************************************************/
 int check_rectangle(float peri,float diagon);
 /*!
 * @brief <Check the input that match a rectangle or not>
 *
 * @param peri <is the perimeter that user entered>.
 * @param diagonal <is the diagonal that user entered>.
 *
 * @return <1 : this is a rectangle
			0 : this is not a rectancle >.
 */
 
 float area_calc(float peri,float diagon);
 /*!
 * @brief <Calculate the area of rectancle>
 *
 * @param peri <is the perimeter that user entered>.
 * @param diagonal <is the diagonal that user entered>.
 *
 * @return <area in float type>.
 */
 #endif /*_ASS31_H_*/
