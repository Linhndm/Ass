/*@filename ChamNP_calcu_area_ass3.c
* @author: ChamNP 
* @topic: function and array 
*/
#include <stdio.h>
/*******************************************************************************
 * Prototypes
 ******************************************************************************/
typedef enum{true,false}bool_t;
float calcuArea(float perimeter,float diagonal);
void input(float *perimeter,float *diagonal);
void output(float area,float perimeter,float diagonal);
bool_t errInput(float perimeter,float diagonal);
/*******************************************************************************
 * API
 ******************************************************************************/
/*@function float calcuArea(float perimeter,float diagonal);
* @brief calculation the area of rectangle
* @param float perimeter  Put perimeter into the function
* @param float diagonal  Put diagonal into the function
* @return calculation the area of rectangle type float
*******************************************************************************/
/*@function void input(float *perimeter,float *diagonal)
* @brief enter perimeter and diagonal of a rectangle
* @param float *perimeter  Put address of the perimeter into the function
* @param float *diagonal  Put address of the the diagonal into the function
* @return No return value
*******************************************************************************/
/*@function output(float area,float perimeter,float diagonal)
* @brief printf perimeter, diagonal and area 
* @param area Put rectangular area after calculation into the function
* @param float perimeter  Put perimeter into the function
* @param float diagonal  Put diagonal into the function
* @return No return value
*******************************************************************************/
/*@function errInput(float perimeter,float diagonal)
* @brief check error input
* @param float perimeter  Put perimeter into the function
* @param float diagonal  Put diagonal into the function
* @return true error input
         false not error
*******************************************************************************/
/*******************************************************************************
* Code
******************************************************************************/
int main()
{
    float perimeter,diagonal,area;
    char ch;/*charater input*/
    do
    {
        do
        {
            /*enter perimeter and diagona*/
            input(&perimeter,&diagonal);
            /*check perimeter and diagona
            **if errInput return true printf errer and re-enter perimeter and diagona
            **if errInput return false then Calculate rectangular area and print to screen*/
            errInput(perimeter,diagonal);
            if(errInput(perimeter,diagonal)==true)
            {
                printf("perimeter or diagonal available number!\n");
            }
        }while(errInput(perimeter,diagonal)==true);
        area=calcuArea(perimeter,diagonal);
        output(area,perimeter,diagonal);
        printf("Press any ket ro continue, ESC to exit!\n");
        /*Check the character entered by the user, 
        **if the character ESC to exit the program,
        **if the other characters to continue the program.*/
        ch=getch();
    }while(ch!=27);
    return 0;
}
void input(float *perimeter,float *diagonal)
{
    /*enter perimeter and diagonal*/
    printf("Enter perimeter:\n");
    scanf("%f",perimeter);
    printf("Enter diagonal:\n");
    scanf("%f",diagonal);
}
void output(float area,float perimeter,float diagonal)
{
    printf("perimeter of a rectangle=%0.2f\n",perimeter);
    printf("diagonal of a rectangle=%0.2f\n",diagonal);
    printf("Area of a rectangle=%0.2f\n",area);
}
float calcuArea(float perimeter,float diagonal)
{
    return (((perimeter*perimeter)/4)-(diagonal*diagonal))/2;
}
bool_t errInput(float perimeter,float diagonal)
{
    /*if perimeter or diagonal <=0 then return -1 error*/
    if(perimeter<=0||diagonal<=0)
    {
        return true;
    }
    else
    {
        /*if 2*perimeter > diagonal then return -1 error
        **else return 0*/
        if(2*diagonal>perimeter)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
}