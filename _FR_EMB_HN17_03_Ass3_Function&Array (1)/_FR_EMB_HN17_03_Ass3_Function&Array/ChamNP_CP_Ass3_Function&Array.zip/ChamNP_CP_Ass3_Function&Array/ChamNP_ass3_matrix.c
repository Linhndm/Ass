/*@filename ChamNP_ass3_matrix.c
* @author: ChamNP 
* @topic: function and array 
*/
#include <stdio.h>
#include <stdint.h>
 /*******************************************************************************
 * Definitions
 ******************************************************************************/
#define MATRIX_A 'A'
#define MATRIX_B 'B'
 /*The largest number of elements of the matrix*/
#define MAX 20
/*******************************************************************************
 * Prototypes
 ******************************************************************************/
typedef enum {false,true} bool_t;
typedef enum{A_Multi_B,B_Multi_A,BothCases,notMulti}matrixMulti_t;
void input(float matrix[MAX][MAX],char matName,int *row,int *column);
void output(float matrix[MAX][MAX],int row,int column);
bool_t errInput(int row,int column);
bool_t checkMatrixAdd(int rowMatA,int columnMatA,int rowMatB,int columnMatB);
void matrixAdd(float matrixA[MAX][MAX],float matrixB[MAX][MAX],float matAdd[MAX][MAX],int row,int column);
matrixMulti_t checkMatrixMulti(int rowMatA,int columnMatA,int rowMatB,int columnMatB);
void matrixMulti(float matrixA[MAX][MAX],float matrixB[MAX][MAX],float matMulti[MAX][MAX],int rowMatA,int columnMatA,int rowMatB,int columnMatB);
/*******************************************************************************
 * API
 ******************************************************************************/
 /*!
*@funct void input(float matrix[MAX][MAX],char MATRIX,int *row,int *column)
*@brief Enter row, columnthe and elements of the matrix
*@param float matrix[MAX][MAX] Put the matrix into the function
*@param matName Put the name of the matrix into the function
*@param *row Put the row address of the matrix into the function
*@param *column Put the column address of the matrix into the function
*@return No return value
*/
/*!
*@funct void output(float matrix[MAX][MAX],int row,int column)
*@brief Print matrix to screen
*@param float matrix[MAX][MAX] Put the matrix into the function
*@param row Put the row of the matrix into the function
*@param column Put the column of the matrix into the function
*@return No return value
*/
/*!
*@funct bool_t errInput(int row,int column);
*@brief check value input, if value input <=0 there is an input error row or column
*@param row Put the row of the matrix into the function
*@param column Put the column of the matrix into the function
*@return    *true There is an error entering the column or row of the matrix
            *false  no error
*/
/*!
*@funct bool_t checkMatrixAdd(int rowMatA,int columnMatA,int rowMatB,int columnMatB)
*@brief check matrix addition can be done or not?
*@param rowMatA Put the row of the matrixA into the function
*@param columnMatA Put the column of the matrixA into the function
*@param rowMatB Put the row of the matrixB into the function
*@param columnMatB Put the column of the matrixB into the function
*@return    *false Matrix can not perform multiplication
            *true  Matrix can perform multiplication
*/
/*!
*@funct int errMatMulti(int rowMatA,int columnMatA,int rowMatB,int columnMatB)
*@brief check matrix multiplication can be done or not?
*@param rowMatA Put the row of the matrixA into the function
*@param columnMatA Put the column of the matrixA into the function
*@param rowMatB Put the row of the matrixB into the function
*@param columnMatB Put the column of the matrixB into the function
*@return    *-1 Matrix can not perform multiplication
            *0  Matrix can perform multiplication
*/
/*!
*@funct void matrixAdd(float matrixA[MAX][MAX],float matrixB[MAX][MAX],float matAdd[MAX][MAX],int row,int column);
*@brief Performs the addition of two matrices
*@param float matrixA[MAX][MAX] Put matrixA into the function
*@param float matrixB[MAX][MAX] Put matrixA into the function
*@param float matAdd[MAX][MAX] Put matAdd into the function, matAdd used to store results addition two matrices
*@param int row Put the row of the matrix into the function
*@param int column Put the column of the matrix into the function
*@return No return value
*/
/*!
*@funct matrixMulti_t checkMatrixMulti(int rowMatA,int columnMatA,int rowMatB,int columnMatB)
*@brief check matrix multiplication can be done or not?
*@param rowMatA Put the row of the matrixA into the function
*@param columnMatA Put the column of the matrixA into the function
*@param rowMatB Put the row of the matrixB into the function
*@param columnMatB Put the column of the matrixB into the function
*@return    *A_Multi_B Matrix A can multiply matrix B
            *B_Multi_A Matrix B can multiply matrix A
            *BothCases Both matrices can be multiplied together
            *notMulti It is not possible to multiply two matrices
*/
/*!
*@funct void matrixMulti(float matrixA[MAX][MAX],float matrixB[MAX][MAX],float matMulti[MAX][MAX],int rowMatA,int columnMatA,int rowMatB,int columnMatB);
*@brief Multiply two matrices
*@param float matrixA[MAX][MAX] Put the matrixA into the function
*@param float matrixB[MAX][MAX] Put the matrixA into the function
*@param float matrixMulti[MAX][MAX] Put the matrixMulti into the function, matrixMulti used to store results multiplying two matrices
*@param rowMatA,columnMatA Put the row and column of the matrixA into the function
*@param rowMatB,columnMatB Put the row and column of the matrixB into the function
*@return No return value
*/
/*******************************************************************************
* Code
******************************************************************************/
int main()
{
    /*Declare the matrix*/
    float matrixA[MAX][MAX],matrixB[MAX][MAX];
    float matAdd[MAX][MAX],matMulti[MAX][MAX];
    int rowMatA,columnMatA,rowMatB,columnMatB;/*Declare row,column of the matrixA,B*/
    matrixMulti_t checkMatMulti;/*Declare chec addition and check multiplication of the matrix*/
    bool_t checkAdd;
    char ch;
    do
    {
        /*enter matrix*/
        input(matrixA,MATRIX_A,&rowMatA,&columnMatA);
        input(matrixB,MATRIX_B,&rowMatB,&columnMatB);
        /*print the matrix to screen*/
        printf("MatrixA after input is:\n");
        output(matrixA,rowMatA,columnMatA);
        printf("MatrixB after input is:\n");
        output(matrixB,rowMatB,columnMatB);
        /*check addition
        *if checkMatrixAdd==true then call function matrixAdd and print matAdd to screen
        *else print to screen message "Can not add two matrices"
        */
        checkAdd=checkMatrixAdd(rowMatA,columnMatA,rowMatB,columnMatB);
        if(checkAdd==true)
        {
            matrixAdd(matrixA,matrixB,matAdd,rowMatB,columnMatB);
            printf("Matrix after addition is:\n");
            output(matAdd,rowMatA,columnMatA);
        }
        else
        {
            printf("Can not add two matrices!\n");
        }
        /*check multiplication
        *if checkMatrixMulti==A_Multi_B then call function matrixMulti(matrixA,matrixB) and print matMulti to screen
        *if checkMatrixMulti==B_Multi_A then call function matrixMulti(matrixB,matrixA) and print matMulti to screen
        *if checkMatrixMulti==BothCases then call function matrixMulti(matrixA,matrixB),matrixMulti(matrixB,matrixA) and print matMulti to screen
        *else print to screen message Can not multiplication two matrices!
        */
        checkMatMulti=checkMatrixMulti(rowMatA,columnMatA,rowMatB,columnMatB);
        switch(checkMatMulti)
        {
            case A_Multi_B:
            {
                matrixMulti(matrixA,matrixB,matMulti,rowMatA,columnMatA,rowMatB,columnMatB);
                printf("Matrix A multiplication B:\n");
                output(matMulti,rowMatA,columnMatB);
                break;
            }
            case B_Multi_A:
            {
                matrixMulti(matrixB,matrixA,matMulti,rowMatB,columnMatB,rowMatA,columnMatA);
                printf("Matrix B multiplication A:\n");
                output(matMulti,rowMatB,columnMatA);
                break;
            }
            case BothCases:
            {
                matrixMulti(matrixA,matrixB,matMulti,rowMatA,columnMatA,rowMatB,columnMatB);
                printf("Matrix A multiplication B:\n");
                output(matMulti,rowMatA,columnMatB);
                matrixMulti(matrixB,matrixA,matMulti,rowMatB,columnMatB,rowMatA,columnMatA);
                printf("Matrix B multiplication A:\n");
                output(matMulti,rowMatB,columnMatA);
                break;
            }
            default:
            {
                printf("Can not multiplication two matrices!\n");
                break;
            }
        }
        /*get charater input
        *If the user press any key then re-run the program
        *press ESC to exit program
        */
        printf("Press any key to continue? Press ESC to exit\n");
        ch=getch();/*get charater input*/
    }while(ch!=27);
    return 0;
}
void input(float matrix[MAX][MAX],char matName,int *row,int *column)
{
    int i,j;
    do
    {
        /*enter the row and column of the matrix*/
        printf("Input row number matrix%c\n",matName);
        scanf("%d",row);
        printf("Input column number matrix%c\n",matName);
        scanf("%d",column);
        /*check error input
        *If the user entered the wrong data, the request to re-enter
        */
        if(errInput(*row,*column)==true)
        {
            printf("Error enter values row or column\n");
        }
    }while(errInput(*row,*column)==true);
    /*Enter the elements of the matrix*/
    printf("tEnter matrix%c\n",matName);
    for(i=0;i<*row;i++)
    {
        for(j=0;j<*column;j++)
        {
            printf("%c[%d][%d]=",matName,i,j);
            scanf("%f",&matrix[i][j]);
        }
    }
}
void output(float matrix[MAX][MAX],int row,int column)
{
    /*print the matrix to screen*/
    int i,j;
    printf("|-----------------------------------------------------------|\n");
    for(i=0;i<row;i++)
    {
        for(j=0;j<column;j++)
        {
            printf("|\tMat[%d][%d]=%0.2f\t",i,j,matrix[i][j]);
        }
        printf("|\n");
    }
    printf("|-----------------------------------------------------------|\n");
}
bool_t errInput(int row,int column)
{
    /*check error input
    *if row or column <=0 return true (error)
    *else return false (no error)
    */
    if(row<=0||column<=0)
    {
        return true;
    }
    else
    {
        return false;
    }
}
bool_t checkMatrixAdd(int rowMatA,int columnMatA,int rowMatB,int columnMatB)
{
    /*check matrix addition
    *if rowMatA=rowMatB and columnMatA=columnMatB return true can be addition two matrix
    *else return false can not addition two matrix
    */
    if(rowMatA==rowMatB&&columnMatA==columnMatB)
    {
        return true;
    }
    else
    {
        return false;
    }
}
matrixMulti_t checkMatrixMulti(int rowMatA,int columnMatA,int rowMatB,int columnMatB)
{
    matrixMulti_t caseMulti;
    /*check matrix multiplication
    *if rowMatA=columnMatB and rowMatB=columnMatA then matrixA multiplication matrixB and matrixB multiplication matrixA
    *if rowMatA=columnMatB and rowMatB!=columnMatA then matrixA multiplication matrixB
    *rowMatA!=columnMatB and rowMatB=columnMatA then matrixB multiplication matrixA
    *if rowMatA=columnMatB=rowMatB=columnMatA=1 then matrixA multiplication matrixB and matrixB multiplication matrixA
    *else can not multiplication the matrix
    */
    if(rowMatA==columnMatB)
    {
        if(rowMatB==columnMatA)
        {
            caseMulti=BothCases;
        }
        else
        {
            caseMulti=A_Multi_B;
        }
    }
    else if((rowMatA==1&&columnMatA==1)||(rowMatB==1&&columnMatB==1))
    {
        caseMulti=B_Multi_A;
    }
    else if(rowMatB==columnMatA)
    {
        caseMulti=B_Multi_A;
    }
    else
    {
        caseMulti=notMulti;
    }
    return caseMulti;
}
void matrixAdd(float matrixA[MAX][MAX],float matrixB[MAX][MAX],float matAdd[MAX][MAX],int row,int column)
{
    uint8_t i,j;
    /*addition the matrix
    *rowMatA+rowMatB and columnMatA+columnMatB
    */
    for(i=0;i<row;i++)
    {
        for(j=0;j<column;j++)
        {
            matAdd[i][j]=matrixA[i][j]+matrixB[i][j];
        }
    }
}
void matrixMulti(float matrixA[MAX][MAX],float matrixB[MAX][MAX],float matMulti[MAX][MAX],int rowMatA,int columnMatA,int rowMatB,int columnMatB)
{
    float temp;
    uint8_t i,j,k;
    /*multiplication matrix*/
    for (i=0;i<rowMatA;i++)
    {
        for (j = 0; j < columnMatB; j++) 
        {
            temp=0;
            for(k =0;k<columnMatA;k++) 
            {
                temp=temp+matrixA[i][k]*matrixB[k][j];
            }
            matMulti[i][j]=temp;
        }
    }
}