/*
 * @author: DongPH
 * @purpose: Assignment 3_Lesson2
 * @filename: Ass3_Ls2.c
 */
#include <stdio.h>
/*******************************************************************************
 * Definitions
 ******************************************************************************/
#define MAX_ROW 100
#define MAX_COLUMN 100
#define PLUS_MATRIX 1
#define NO_PLUS_MATRIX 2
#define MULTI_MATRIX_AB 3
#define MULTI_MATRIX_BA 4
#define MULTI_BOTH_MATRIX 5
#define NO_MULTI_MATRIX 6
/*******************************************************************************
 * API
 ******************************************************************************/
/*!@function void inputMatrix(float matrix[MAX_ROW][MAX_COLUMN],int *row, int *col,char nameMatrix);
 * @brief <Enter matrix>
 * @param float matrix[MAX_ROW][MAX_COLUMN] <matrix needs enter  >.
 * @param int *row <>.
 * @param int *rol<>.
 * @param char nameMatrix <name of matrix needs enter>.
 * @return <no value return>.
 */
void inputMatrix(float matrix[MAX_ROW][MAX_COLUMN],int *row, int *col,char nameMatrix);
/*!@function void showMatrix(float matrix[MAX_ROW][MAX_COLUMN],int row, int col);
 * @brief <display matrix>
 * @param float matrix[MAX_ROW][MAX_COLUMN] <matrix needs display >.
 * @param int row <the number row of matrix>.
 * @param int rol <the number column of matrix>.
 * @return <no value return>.
 */
void showMatrix(float matrix[MAX_ROW][MAX_COLUMN],int row, int col);
/*!@function void plusMatrix(float matrixP[MAX_ROW][MAX_COLUMN],float matrixA[MAX_ROW][MAX_COLUMN],int rowA, int colA,float matrixB[MAX_ROW][MAX_COLUMN],int rowB, int colB);
 * @brief <matrix A plus matrix B>
 * @param float matrixP[MAX_ROW][MAX_COLUMN] <matrix sum then plus two matrix>.
 * @param float matrixA[MAX_ROW][MAX_COLUMN] <the first matrix-matrixA>.
 * @param int rowA <the number row of matrixA>.
 * @param int rolA <the number column of matrixA>.
 * @param float matrixB[MAX_ROW][MAX_COLUMN] <the second matrix-matrixB>.
 * @param int rowB <the number row of matrixB>.
 * @param int rolB <the number column of matrixB>.
 * @return <no value return>.
 */
void plusMatrix(float matrixP[MAX_ROW][MAX_COLUMN],float matrixA[MAX_ROW][MAX_COLUMN],int rowA, int colA,float matrixB[MAX_ROW][MAX_COLUMN],int rowB, int colB);
/*!@function void multiMatrixAB(float matrixM[MAX_ROW][MAX_COLUMN],float matrixA[MAX_ROW][MAX_COLUMN],int rowA, int colA,float matrixB[MAX_ROW][MAX_COLUMN],int rowB, int colB);
 * @brief <matrix A multiplied by matrix B>
 * @param float matrixM[MAX_ROW][MAX_COLUMN] <you get the matrix then multiply matrixA and matrixB >.
 * @param float matrixA[MAX_ROW][MAX_COLUMN] <the first matrix-matrixA>.
 * @param int rowA <the number row of matrixA>.
 * @param int rolA <the number column of matrixA>.
 * @param float matrixB[MAX_ROW][MAX_COLUMN] <the second matrix-matrixB>.
 * @param int rowB <the number row of matrixB>.
 * @param int rolB <the number column of matrixB>.
 * @return <no value return>.
 */
void multiMatrixAB(float matrixM[MAX_ROW][MAX_COLUMN],float matrixA[MAX_ROW][MAX_COLUMN],int rowA, int colA,float matrixB[MAX_ROW][MAX_COLUMN],int rowB, int colB);
/*!@function void multiMatrixBA(float matrixM[MAX_ROW][MAX_COLUMN],float matrixA[MAX_ROW][MAX_COLUMN],int rowA, int colA,float matrixB[MAX_ROW][MAX_COLUMN],int rowB, int colB);
 * @brief <matrix B multiplied by matrix A>
 * @param float matrixM[MAX_ROW][MAX_COLUMN] <you get the matrix then multiply matrixB and matrixA >.
 * @param float matrixB[MAX_ROW][MAX_COLUMN] <the second matrix-matrixB>.
 * @param int rowB <the number row of matrixB>.
 * @param int rolB <the number column of matrixB>.
 * @param float matrixA[MAX_ROW][MAX_COLUMN] <the first matrix-matrixA>.
 * @param int rowA <the number row of matrixA>.
 * @param int rolA <the number column of matrixA>.
 * @return <no value return>.
 */
void multiMatrixBA(float matrixM[MAX_ROW][MAX_COLUMN],float matrixB[MAX_ROW][MAX_COLUMN],int rowB, int colB,float matrixA[MAX_ROW][MAX_COLUMN],int rowA, int colA);
/*!@function int checkPlus(int rowA,int colA,int rowB,int colB);
 * @brief <check the conditions which plus matrix>
 * @param int rowA <the number row of matrixA>.
 * @param int rolA <the number column of matrixA>.
 * @param int rowB <the number row of matrixB>.
 * @param int rolB <the number column of matrixB>.
 * @return <to return type int with values:  
    + PLUS_MATRIX 1
    + NO_PLUS_MATRIX 2 >.
 */
int checkPlus(int rowA,int colA,int rowB,int colB);
/*!@function int checkMultiply(int rowA,int colA,int rowB,int colB);
 * @brief <check the conditions which multiply matrix>
 * @param int rowA <the number row of matrixA>.
 * @param int rolA <the number column of matrixA>.
 * @param int rowB <the number row of matrixB>.
 * @param int rolB <the number column of matrixB>.
 * @return <to return type int with values:  
        + MULTI_MATRIX_AB 3
        + MULTI_MATRIX_BA 4
        + MULTI_BOTH_MATRIX 5
        + NO_MULTI_MATRIX 6 >.
 */
int checkMultiply(int rowA,int colA,int rowB,int colB);
/*!@function void checkInput(int *c_InPut);
 * @brief <check the value which is entered from key board to see wrong or right>
 * @param int *c_InPut <the value is entered from key board and>.
 * @return <no value return >.
 */ 
void checkInput(int *c_InPut);
/*******************************************************************************
 * Code
 ******************************************************************************/
int main()
{
    float matrixA[MAX_ROW][MAX_COLUMN];
    float matrixB[MAX_ROW][MAX_COLUMN];
    float matrixP[MAX_ROW][MAX_COLUMN];
    float matrixM[MAX_ROW][MAX_COLUMN];
    int rowA;
    int colA;
    int rowB;
    int colB;
    int plus;
    int multi;
    char mtA='A',mtB='B',kt;
    /*the loop do-while used to repeat the program if we want to continue*/
    do
    {
        /*Enter matrix A and matrix B from the key board and display them*/
        printf("Enter Matrix A:\n");
        inputMatrix(matrixA,&rowA,&colA,mtA);
        printf("Matrix A is:\n");
        showMatrix(matrixA,rowA,colA);
        printf("\n------------------------------------------------------------\n");
        printf("\nEnter Matrix B:\n");
        inputMatrix(matrixB,&rowB,&colB,mtB);
        printf("Matrix B is:\n");
        showMatrix(matrixB,rowB,colB);
        printf("\n------------------------------------------------------------\n");
        plus=checkPlus(rowA,colA,rowB,colB);
        if(plus == PLUS_MATRIX )
        {
            printf("MatrixA combined with MatrixB !!!\n");
            plusMatrix(matrixP,matrixA,rowA,colA,matrixA,rowB,colB);
            printf("Matrix plus is: \n");
            showMatrix(matrixP,rowA,colA);
        }
        else
        {
            printf("Don't plus matrix!\n");
        }
        printf("\n------------------------------------------------------------\n");
        multi=checkMultiply(rowA,colA,rowB,colB);
        if(multi == MULTI_MATRIX_AB)
        {
            printf("MatrixA multiplied by MatrixB !!! \n");
            multiMatrixAB(matrixM,matrixA,rowA,colA,matrixB,rowB,colB);
            printf("MatrixA*B is: \n");
            showMatrix(matrixM,rowA,colB);
        }
        else if(multi == MULTI_MATRIX_BA)
        {
            printf("MatrixB multiplied by MatrixA !!! \n");
            multiMatrixBA(matrixM,matrixB,rowB,colB,matrixA,rowA,colA);
            printf("MatrixB*A is: \n");
            showMatrix(matrixM,rowB,colA);
        }
        else if(multi == MULTI_BOTH_MATRIX)
        {
            printf("MatrixA multiplied by MatrixB !!! \n");
            multiMatrixAB(matrixM,matrixA,rowA,colA,matrixB,rowB,colB);
            printf("MatrixA*B is: \n");
            showMatrix(matrixM,rowA,colB);
            printf("\n------------------------------------------------------------\n");
            printf("MatrixB multiplied by MatrixA !!! \n");
            multiMatrixBA(matrixM,matrixB,rowB,colB,matrixA,rowA,colA);
            printf("MatrixB*A is: \n");
            showMatrix(matrixM,rowB,colA);
        }
        else
        {
            printf("Don't multiplicate matrix!\n");
        }
        printf("\n------------------------------------------------------------\n");
        printf("\nDo you want to continue?\n");
        printf("\nPress Y to continue, press any key to exit!\n");
        kt=getch();
    }while(kt=='y');    
    return 0;
}
void inputMatrix(float matrix[MAX_ROW][MAX_COLUMN],int *row, int *col,char nameMatrix)
{
    int i,j;
    printf("Enter row:");
    checkInput(row);
    printf("Enter column:");
    checkInput(col);
    for(i=0;i<*row;i++)
    {
        for(j=0;j<*col;j++)
        {
            printf("%c[%d][%d]=",nameMatrix,i,j);
            scanf("%f",&matrix[i][j]);
        }
    }
}
void showMatrix(float matrix[MAX_ROW][MAX_COLUMN],int row, int col)
{
    int i,j;
    for(i=0;i<row;i++)
    {
        printf("\n");
        for(j=0;j<col;j++)
        {
            printf("%.1f\t",matrix[i][j]);
        }
    }
}
void plusMatrix(float matrixP[MAX_ROW][MAX_COLUMN],float matrixA[MAX_ROW][MAX_COLUMN],int rowA, int colA,float matrixB[MAX_ROW][MAX_COLUMN],int rowB, int colB)
{
    int i,j;
    for(i=0;i<rowA;i++)
    {
        for(j=0;j<colA;j++)
        {
            matrixP[i][j]= matrixA[i][j] + matrixB[i][j];
        }
    }
}
void multiMatrixAB(float matrixM[MAX_ROW][MAX_COLUMN],float matrixA[MAX_ROW][MAX_COLUMN],int rowA, int colA,float matrixB[MAX_ROW][MAX_COLUMN],int rowB, int colB)
{
    int i,j,k;
    for(i=0;i<rowA;i++)
    {
        for(j=0;j<colB;j++)
        {
            matrixM[i][j]= 0;
            for(k=0;k<rowB;k++)
            {
                matrixM[i][j] += matrixA[i][k]*matrixB[k][j];
            }
        }
    }
}
void multiMatrixBA(float matrixM[MAX_ROW][MAX_COLUMN],float matrixB[MAX_ROW][MAX_COLUMN],int rowB, int colB,float matrixA[MAX_ROW][MAX_COLUMN],int rowA, int colA)
{
    int i,j,k;
    for(i=0;i<rowB;i++)
    {
        for(j=0;j<colA;j++)
        {
            matrixM[i][j]= 0;
            for(k=0;k<rowA;k++)
            {
                matrixM[i][j] += matrixB[i][k]*matrixA[k][j];
            }
        }
    }
}
void checkInput(int *c_InPut)
{
    /*check condition when we enter row and col of matrix,it have to value bigger than 0
    If we enter wrong,we'll enter again until we enter correct*/
    do
    {
        scanf("%d",c_InPut);
        if(*c_InPut<0)
        {
            printf("Incorrect! Enter again!\n");
        }
    }while(*c_InPut<0);
}
int checkPlus(int rowA,int colA,int rowB,int colB)
{
    /*check condition plus matrix. If two matrixs have same row and same column, we'll can plus matrix else we'll can't plus matrix  */
    if(rowA==rowB && colA==colB)
    {
        return PLUS_MATRIX;
    }
    else
    {
        return NO_PLUS_MATRIX;
    }
}
int checkMultiply(int rowA,int colA,int rowB,int colB)
{   
    /*check condition multiply matrix. If two matrixs have both row and column is equal,
    or column of matrix A is equal row of matrix B and row of matrix A is equal col of matrix B, 
    we'll can multiply matrix A and B or multiply matrix B and A.  
    If column of matrix A is equal row of matrix B, we only matrix A multiplied by matrix B
    If column of matrix B is equal row of matrix A, we only  matrix B multiplied by matrix A
    If cases above don't happen,we'll can't multiply matrix*/
    if(colA==rowB && colB==rowA)
    {
        return MULTI_BOTH_MATRIX;
    }
    else if(colA==rowB)
    {
        return MULTI_MATRIX_AB;
    }
    else if(colB==rowA)
    {
        return MULTI_MATRIX_BA;
    }
    else
    {
        return NO_MULTI_MATRIX;
    }
}
