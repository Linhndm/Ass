/*
 * @author: DongPH
 * @purpose: Assignment 3_Lesson1
 * @filename: Ass3_Ls1.c
 */
#include <stdio.h>
/*******************************************************************************
 * API
 ******************************************************************************/
/*@function float Calculate_Area(float Perimeter,float Diagonal_line);
* @brief: Calculate the area of  rectangle.
* @param: 
            + Perimeter: Perimeter of rectangle.
            + Diagonal: Diagonal of rectangle.
* @return: S: Area of rectangle.
*******************************************************************************/
float Calculate_Area(float Perimeter,float Diagonal_line);
/*******************************************************************************
 * Code
 ******************************************************************************/
int main()
{
    char kt;
    float Perimeter;
    float Diagonal_line;
    float S;
    do
    {
        do
           {
            /*The user enters the value of perimeter and diagonal line*/
               printf("Enter Perimeter: ");
            scanf("%f",&Perimeter);
            printf("Enter Diagonal line:");
            scanf("%f",&Diagonal_line);
            /*+ Check the value entered wrong or right. If wrong, it'll printf:The rectangle does not exist!Re enter!
              + The conditions check: Perimeter and Diagonal line are bigger than 0
                                      Perimeter is bigger than 2*Diagonal line */
               if (Perimeter<=0||Diagonal_line<=0||Perimeter<=2*Diagonal_line)
               {
                   printf("The rectangle does not exist!Re enter!\n");
               }
        }while (Perimeter<=0||Diagonal_line<=0||Perimeter<=2*Diagonal_line);
        /*Call function calculate area of rectangle.*/       
        S= Calculate_Area(Perimeter,Diagonal_line);
        printf("This rectangular area is:%.2f ",S);
        /*Ask the user want to enter again? Y=yes,N=no*/
        printf("\nDo you want to continues? \n");
        printf("\nPress Y to continue, press any key to exit\n");
        kt=getch();
    }while(kt=='y');      
    return 0;
}
float Calculate_Area(float Perimeter,float Diagonal_line)
{
    float S;
    S =((Perimeter*Perimeter)/4.0 - Diagonal_line*Diagonal_line)/2.0;
    return S;
}


