#include <stdio.h>
#include <stdlib.h>
#define n 40

/*<perform function input row and column of matrix >*/
int Input_roco()
{
    int roco;
    do{
        printf("Input row/col of Matrix :");/*<input value Row or Column of Matrix >*/
        scanf("%d",&roco);
        if(roco<=0)
        {
            printf("Fail !\n");
            printf("input again\n");
        }
    }while(roco<=0);
    return roco;/*<Return value row or column of Matrix>*/
}
/*<perform function input value of matrix>*/
void Input_matrix(float matrix[],int row,int col)
{
    int i;
    for(i=0;i<row*col;i++)
    {
        printf("input matrix :");/*<input value of Matrix>*/
        scanf("%f",&matrix[i]);
    }
}
/*<display matrix to screen>*/
void Output_matrix(float matrix[],int row,int col)
{
    int i,t=0;
    for(i=0;i<row*col;i++)
    {
        printf("%.2f  ",matrix[i]);/*<print value of matrix>*/
        if(i==(t+col-1))/*<down the line when end one row>*/
        {
            printf("\n");
            t+=col;/*<augment t for next row>*/
        }
    }
}
/*<Function check and Multiply two Matrix>*/
void Plus_matrix(float matrixa[],int rowa,int cola,float matrixb[],int rowb,int colb)
{
    float matrixC[n];
    int i,t=0;
    /*<Plus Matrix A with MatrixB>*/
    if(rowa==rowb && cola==colb)/*<condition two matrix can plus with together>*/
    {
        printf("Two matrix can plus !\n");
        for(i=0;i<rowa*colb;i++)
        {
            matrixC[i]=matrixa[i]+matrixb[i];/*<plus each value MatrixA with each value MatrixB>*/
        }
        printf("Matrix after plus is:\n");
        Output_matrix(matrixC,rowa,rowb);/*<print to screen result plus Two Matrix>*/
    }
    else
    {
        printf("Don't plus Two matrix !\n'");
    }
}
/*<Function Multiply two Matrix>*/
void Mutil_matrix(float matrixa[],int rowa,int cola,float matrixb[],int rowb,int colb)
{
    float matrixD[n];
    int i,j,k;
    /*<Multiply Matrix A with MatrixB>*/
    /*<Algorithm Multiply Two Matrix with together>*/
    for(i=0;i<rowa;i++)
    {
        for(j=0;j<colb;j++)
        {
            matrixD[colb*i+j]=0;
            for(k=0;k<cola;k++)
            {
                matrixD[colb*i+j]+=matrixa[cola*i+k]*matrixb[colb*k+j];
            }
        }
    }
    printf("Result multiply Two Matrix is:\n");
    Output_matrix(matrixD,rowa,colb);/*<print to screen result multiply Two Matrix>*/
}
/*<Function check case rowa=cola=1 or rowb=colb=1..MatrixA and MAtrixB also can Multiply with together>*/
void Multi_spe(float matrixa[],int rowa,int cola,float matrixb[],int rowb,int colb)
{
    float matrixD[n];
    int i;
    /*<perform MatrixA(rowa=cola=1) Multiply with matrixB >*/
    for(i=0;i<rowb*colb;i++)
    {
        matrixD[i]=matrixa[0]*matrixb[i];
    }
    printf("Result multiply Two Matrix is:\n");
    Output_matrix(matrixD,rowb,colb);/*<display matrix to screen result Matrix>*/
}

/*<Check condition multiply Two Matrix>*/
void check_matrix(float matrixa[],int rowa,int cola,float matrixb[],int rowb,int colb)
{
    if(cola==rowb)/*<if column Matrix A same row Matrix B..MatrixA can Multiply with MatrixB>*/
    {
        printf("MatrixA can multiply with MatrixB !\n");
        Mutil_matrix(matrixa,rowa,cola,matrixb,rowb,colb);/*<perform function Multiply matrixA with matrixB>*/
        if(rowa==colb)/*<in condition column a=row b..that row matrixA same column matrix B..MatrixB also Multiply with MatrixA>*/
        {
            printf("MatrixB also can multiply with MatrixA !\n");
            Mutil_matrix(matrixb,rowb,colb,matrixa,rowa,cola);/*<perform Function Multiply matrixB with matrixA>*/
        }
    }
    else if(rowa==colb)/*<if row Matrix A same column Matrix B..MatrixB can Multiply with MatrixA>*/
    {
        printf("MatrixB can multiply with MatrixA !\n");
        Mutil_matrix(matrixb,rowb,colb,matrixa,rowa,cola);/*<perform function Multiply matrixB with matrixA>*/
    }
    else if(rowa==1&&cola==1)/*<Special case row matrixA same column matrixA>*/
    {
        Multi_spe(matrixa,rowa,cola,matrixb,rowb,colb);/*<perform Function Multiply matrixA/B with matrixB/A>*/
    }
    else if(rowb==1&&colb==1)/*<Special case row matrixB same column matrixB>*/
    {
        Multi_spe(matrixb,rowb,colb,matrixa,rowa,cola);/*<perform Function Multiply matrixA/B with matrixB/A>*/
    }
    else
    {
        printf("Don't Mutilply Two Matrix !\n'");/*<if don't satisfy condition above..notification Two Matrix don't Multiply with together>*/
    }
}

