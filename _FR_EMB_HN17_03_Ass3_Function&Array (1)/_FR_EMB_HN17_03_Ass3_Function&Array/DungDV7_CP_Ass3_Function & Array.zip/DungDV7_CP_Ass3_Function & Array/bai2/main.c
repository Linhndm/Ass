#include <stdio.h>
#include <stdlib.h>
#define n 40

/*<function main program>*/
/*<	perform other function>*/
void main()
{
    char select;
    do{
    int row1,col1,row2,col2;
    float matrixA[n];/*Declare Array Matrix A include n value>*/
    printf("Input Matrix A !\n");
    row1=Input_roco();/*<perform function input row and column of matrixA >*/
    col1=Input_roco();/*<perform function input row and column of matrixA >*/
    Input_matrix(matrixA,row1,col1);/*<perform function input value of matrix A>*/
    printf("Matrix A is :\n");
    Output_matrix(matrixA,row1,col1);/*<display matrixA to screen>*/
     
    float matrixB[n];/*Declare Array Matrix A include n value>*/
    printf("Input Matrix B !\n");
    row2=Input_roco();/*<perform function input row and column of matrix B >*/
    col2=Input_roco();/*<perform function input row and column of matrix B >*/
    Input_matrix(matrixB,row2,col2);/*<perform function input value of matrix B>*/
    printf("Matrix B is :\n");
    Output_matrix(matrixB,row2,col2);/*<display matrixB to screen>*/
    Plus_matrix(matrixA,row1,col1,matrixB,row2,col2);/*<Perform Function Plus Two Matrix>*/
    check_matrix(matrixA,row1,col1,matrixB,row2,col2);/*<Funciton check condition..Can Two matrix Multiply with together?*/ 
    printf("Do you want to input Matrix again !\n");
    printf("Input Yes or No (y/n) \n");
    select=getch();
    }while(select=='y');/*<if user want use program again then can press 'y'>*/
}
