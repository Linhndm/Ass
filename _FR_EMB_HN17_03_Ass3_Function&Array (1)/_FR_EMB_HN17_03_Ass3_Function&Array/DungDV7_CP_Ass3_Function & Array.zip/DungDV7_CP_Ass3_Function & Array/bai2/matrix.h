#ifndef _matrix_H_
#define _matrix_H_

/*******************************************************************************
 * Definitions
 ******************************************************************************/
#define MACRO2 2

/*******************************************************************************
 * API
 ******************************************************************************/
/*<perform function input row and column of matrix >*/
int Input_roco();
/*<perform function input value of matrix A>*/
void Input_matrix(float matrix[],int row,int col);
/*<display matrixA>*/
void Output_matrix(float matrix[],int row,int col);
/*<Perform function multiplication Two 2 MAtrix>*/
void Multi_matrix(float []matrixa,int rowa,int cola,float matrixb[],int rowb,int colb);
/*<Check condition multiplication Two Matrix>*/
void check_matrix(float matrixa[],int rowa,int cola,float matrixb[],int rowb,int colb);
/*<function check case row1=col1=1 or row2=col2=1>*/
void checkmatrix_spe(float matrixa[],int rowa,int cola,float matrixb[],int rowb,int colb);

#endif /* _HEADER_FILENAME_H_ */
