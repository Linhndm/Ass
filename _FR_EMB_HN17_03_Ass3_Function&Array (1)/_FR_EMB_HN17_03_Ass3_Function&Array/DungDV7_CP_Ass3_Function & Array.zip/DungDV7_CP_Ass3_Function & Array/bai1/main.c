#include <stdio.h>
#include <stdlib.h>

/*<Functinon:figure out acreage of rectangle>*/
void Input(float peri,float diag)
{
    float acr; /*<declare variable of acreage>*/
    if((diag*diag)>(peri*peri)/8 && (diag*diag)<(peri*peri)/4)/*<condition exist of rectangle>*/
    {
        acr=((peri*peri)/8-(diag*diag)/2);/*<recipe figure out acreage of rectangle use perimeter and diagonal line>*/
        printf("Acreage Rectangle = %.2f",acr);/*<print result acreage of rectangle>*/
    }
    else/*<opposite>*/
    {
        printf("Not Rectangles !\n");/*<print Not Rectangles>*/
    }
}

/*<Function Main Program>*/
void main()
{
    float peri,diag;
    do{/*<input perimeter and diagonal line of rectangle>*/
    printf("Input Value perimeter:");/*<Input Value perimeter>*/
    scanf("%f",&peri);
    printf("Input diagonal line:");/*<Input Value diagonal line>*/
    scanf("%f",&diag);
    if(peri<=0 || diag<=0)
    {
        printf("Fail !\n");
        printf("Input again !\n");
    }
    }while(peri<=0 || diag<=0);/*<retype value perimeter and diagonal line if value perimeter or diagonal line < 0 >*/
    Input(peri,diag);/*<perform Function>*/
}
