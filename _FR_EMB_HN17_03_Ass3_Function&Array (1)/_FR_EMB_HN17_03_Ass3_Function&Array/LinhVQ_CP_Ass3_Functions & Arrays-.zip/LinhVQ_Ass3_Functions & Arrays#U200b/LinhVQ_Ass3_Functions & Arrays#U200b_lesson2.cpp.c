#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <stdint.h>

#define MAX_SIZE    20

typedef enum{
    e_SUMMUL = 0u, /*The two matrix can sum and multiply*/
    e_NOTMUL = 1u, /*The two matrix can not sum and can not multiply*/
    e_NSUMMUL = 2u, /*The two matrix can not sum but can multiply*/
}flagMatrix_t;

/*
Function : inputMatrix(int a[][MAX_SIZE], int row, int col)
    @brief: input matrix
    @param:
                + a[][MAX_SIZE] : array 2 dimensional (matrix input)
                + row : row of matrix a
                + col : column of matrix a
    @return: none
*/
void inputMatrix(int a[][MAX_SIZE], int row, int col);

/*
Function : void printMatrix(int a[][MAX_SIZE], int row, int col)
    @brief: printf matrix
    @param:
                + a[][MAX_SIZE] : array 2 dimensional (matrix input)
                + row : row of matrix
                + col : column of matrix
    @return: None
*/
void printMatrix(int a[][MAX_SIZE], int row, int col);

/*
Function : flagMatrix_t checkMatrix(int row_1, int col_1, int row_2, int col_2)
    @brief: check matrix (sum and multiply)
    @param:
                + row_1 : row of first matrix
                + col_1 : column of first matrix
                + row_2 : row of second matrix
                + col_2 : column of second matrix
    @return: 
                + e_SUMMUL : The two matrix can sum and multiply
                + e_NOTMUL : The two matrix can not sum and can not multiply
                + e_NSUMMUL :The two matrix can not sum but can multiply
*/
flagMatrix_t checkMatrix(int row_1, int col_1, int row_2, int col_2);

/*
Function : void sumMatrix(int a[][MAX_SIZE], int b[][MAX_SIZE], int c[][MAX_SIZE], int row_1, int col_1, int row_2, int col_2)
    @brief: multiply the two matrix
    @param:
                + a[][MAX_SIZE] : array 2 dimensional (matrix input)
                + b[][MAX_SIZE] : pointer 2 dimensional (matrix input)
                + c[][MAX_SIZE] : pointer 2 dimensional (matrix sum)
                + row_1 : row of matrix 1st
                + col_1 : column of matrix 1st
                + row_2 : row of matrix 2nd
                + col_1 : column of matrix 2nd
    @return: None
*/
void sumMatrix(int a[][MAX_SIZE], int b[][MAX_SIZE], int c[][MAX_SIZE], int row_1, int col_1, int row_2, int col_2) ;

/*
Function : void mulMatrix(int a[][MAX_SIZE], int b[][MAX_SIZE], int c[][MAX_SIZE], int row_1, int col_1, int row_2, int col_2)
    @brief: multiply the two matrix
    @param:
                + a[][MAX_SIZE] : array 2 dimensional (matrix input)
                + b[][MAX_SIZE] : pointer 2 dimensional (matrix input)
                + c[][MAX_SIZE] : pointer 2 dimensional (matrix multiply)
                + row_1 : row of matrix 1st
                + col_1 : column of matrix 1st
                + row_2 : row of matrix 2nd
                + col_1 : column of matrix 2nd
    @return: None
*/
void mulMatrix(int a[][MAX_SIZE], int b[][MAX_SIZE], int c[][MAX_SIZE], int row_1, int col_1, int row_2, int col_2) ;

int main()
{
    int mat_1[MAX_SIZE][MAX_SIZE];
    int mat_2[MAX_SIZE][MAX_SIZE];
    int matResult_1[MAX_SIZE][MAX_SIZE];
    int matResult_2[MAX_SIZE][MAX_SIZE];
    int row_1, col_1, row_2, col_2;
    flagMatrix_t flag;
    printf("Input matrix A: \n");
    printf("Input row: \n");
    scanf("%d",&row_1);
    printf("Input column: \n");
    scanf("%d",&col_1);
    inputMatrix(mat_1, row_1, col_1);
    printf("Input matrix B: \n");
    printf("Input row: \n");
    scanf("%d",&row_2);
    printf("Input column: \n");
    scanf("%d",&col_2);
    inputMatrix(mat_2, row_2, col_2);
    flag = checkMatrix(row_1, col_1, row_2, col_2);
    printf("Matrix A = \n");
    printMatrix(mat_1, row_1, col_1);
    printf("Matrix B = \n");
    printMatrix(mat_2, row_2, col_2);
    sumMatrix(mat_1, mat_2, matResult_1, row_1, col_1, row_2, col_2);
    /*Matrix can multiply*/
    if(flag == e_SUMMUL)
    {
        printMatrix(matResult_1, row_1, col_1);
    }
    mulMatrix(mat_1, mat_2, matResult_2, row_1, col_1, row_2, col_2);
    if((flag == e_SUMMUL) || (flag == e_NSUMMUL))
    {
        printMatrix(matResult_2, row_1, col_2);
    }
    getch();
    return 0;
}

void inputMatrix(int a[][MAX_SIZE], int row, int col)
{
    int i, j;
    if((row <= 0) || (col <= 0))
    {
        printf("Size error !!!");
    }
    for(i = 0; i<row; i++)
    {
        for(j = 0; j<col; j++)
        {
            printf("Input a[%d][%d] : ",i+1,j+1);
            scanf("%d",&a[i][j]);
        }
    }
}
void printMatrix(int a[][MAX_SIZE], int row, int col)
{
    int i, j;
    for(i = 0; i<row; i++)
    {
        for(j = 0; j<col; j++)
        {
            printf("%d\t",a[i][j]);
        }
        printf("\n");
    }
}
flagMatrix_t checkMatrix(int row_1, int col_1, int row_2, int col_2)
{
    /*Check sum and multiply*/
    flagMatrix_t flagM = e_NOTMUL;
    if((row_1 == row_2) && (col_1 == col_2))
    {
        flagM = e_SUMMUL;
        return flagM;
    }
    if(col_1 == row_2)
    {
        flagM = e_NSUMMUL;
        return flagM;
    }
    return flagM;
}

void sumMatrix(int a[][MAX_SIZE], int b[][MAX_SIZE], int c[][MAX_SIZE], int row_1, int col_1, int row_2, int col_2) 
{
    int i,j;
    flagMatrix_t flag;
    flag = checkMatrix(row_1, col_1, row_2, col_2);
    if((flag == e_NOTMUL) || (flag == e_NSUMMUL))
    {
        printf("Two matrix can not sum !!!\n");
    }
    else
    {
        printf("Two matrix can sum !!! \nSum = \n");
        for(i = 0; i < row_1; i++)
        {
            for(j = 0; j < col_1; j++)
            {
                c[i][j] = a[i][j]+b[i][j];
            }
        }
    }
}


void mulMatrix(int a[][MAX_SIZE], int b[][MAX_SIZE], int c[][MAX_SIZE], int row_1, int col_1, int row_2, int col_2) 
{
    int i, j, k;
    flagMatrix_t flag = checkMatrix(row_1, col_1, row_2, col_2);
    /* The first matrix can multiply with second matrix */
    if((flag == e_SUMMUL) || (flag == e_NSUMMUL))
    {
        printf("The two matrix multiply :!!!\nMul = \n");
        for(i = 0; i<row_1;i++)
        {
            for(j = 0; j< col_2; j++)
            {
                /* multiply the position i j*/
                for(k = 0; k < row_2; k++)
                {
                    c[i][j] += a[i][k]*b[k][j];
                }
            }
        }
    }
    else
    {
        printf("The two can not matrix multiply :!!!\n");
    }
}