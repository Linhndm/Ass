/*
 * @author: LinhVQ
 * @purpose: Assignment 3
 * @filename: Ass3.cpp
 */
 
#include <stdio.h>
#include <conio.h>
#include <stdint.h>

#define SIZE_ERR     -2
#define RECT_ERR     -1
#define NOT_RECT     0
#define TRUE_RECT    1


/*
Function : int8_t isRect(float p, float d, float &area)
    @brief: check is rectangle
    @param:
                + p : perimeter of the rectangle
                + d : diagonal line of the rectangle
                + area : area of the rectangle
    @return: error input
*/
int8_t isRect(float p, float d, float &area);

/*
Function : float cal_Area()
    @brief: calculate area of the rectangle
    @param: none
    @return: area : area of the rectangle
*/
float cal_Area();

int main()
{
    float area;
    area = cal_Area();
    printf("Area is : %0.3f\n", area);
    getch();
    return 0;
}

int8_t isRect(float p, float d, float &area)
{
    float areaTemp;
    if( p <= 0 || d <= 0)
    {
        printf("Size error !\n");
        return SIZE_ERR;
    }
    if(p/2.0 <= d)
    {
        printf("Size is not rectangle !\n");
        return RECT_ERR;
    }
    /*area */
    areaTemp = ((p/2.0)*(p/2.0) - (d*d))/2.0;
    if(areaTemp <= 0)
    {
        printf("Is not rectangle !\n");
        return NOT_RECT;
    }
    else
    {
        area = areaTemp;
        return TRUE_RECT;
    }
    return TRUE_RECT;
}

float cal_Area()
{
    float p;
    float d;
    float area;
    int8_t err;
    do
    {
        printf("Input perimeter :\n");
        scanf("%f",&p);
        printf("Input diagonal line :\n");
        scanf("%f",&d);
        err = isRect(p, d, area);
        printf("Status : %d \n",err);
    }
    while(err != TRUE_RECT);
    return area;
}
