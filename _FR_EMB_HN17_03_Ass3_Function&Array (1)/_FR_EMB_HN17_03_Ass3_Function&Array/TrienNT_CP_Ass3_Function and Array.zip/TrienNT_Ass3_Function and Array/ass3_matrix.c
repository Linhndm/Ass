/*Program the sum and multiplication of two matrix
**Check condition of Sum and Multiplicaton
***************************************************************************/
#include<stdio.h>
#include<stdint.h>
/*************************************************************************
**Definitions
***************************************************************************/
#define TRUE 1
#define FALSE 0
/**************************************************************************
**Prototype
***************************************************************************/
void readMatrix(float a[100][100], int row, int col);
void printMatrix(float a[100][100], int row, int col);
int checkChar( float a);
int checkSum(int rowA, int colA, int rowB, int colB);
int checkMul(int rowA, int colA, int rowB, int colB);
void sumMatrix(float a[100][100], float b[100][100],float c[100][100], int row, int col);
void mulMatrix(float a[100][100], float b[100][100], float c[100][100], int rowA, int colA,int colB);
/***************************************************************************
**Code
****************************************************************************/
/*
** Function: Read matrix from keybord
** Param:    a is matrix, row and col is value of row and column of matrix
*/
void readMatrix(float a[100][100], int row, int col)
{
    int i,j;
    if(row<=0||col<=0)
    {
        printf("Input value wrong.\n");
    }
    else
    {
        for(i=0;i<row;i++)
        {
            for(j=0;j<col;j++)
            {
                printf("a[%d][%d]= ",i,j);
                scanf("%f",&a[i][j]);
            }
        }
    }
}
/*
** Function: print matrix 
** Param:    a is matrix, row and col is value of row and column of matrix
*/
void printMatrix(float a[100][100], int row, int col)
{
    int i,j;
    for(i=0;i<row;i++)
    {
        for(j=0;j<col;j++)
        {
            printf("%5.2f ",a[i][j]);
            if(j==col-1)
            {
                printf("\n");
            }
        }
    }
}
int checkChar( float a)
{
   if(a>'9'||a<'0')
   {
        return FALSE;
   }
   else
   {
        return TRUE;
   }
}
/*
** Function: check input condition of Sum
** Param:    rowA, colA, rowB, colB is number of row and column of matrix a and b
*/
int checkSum(int rowA, int colA, int rowB, int colB)
{
    if(rowA==rowB&&colA==colB)
    {
        return TRUE;/*true  input condition*/
    }
    else
    {
        return FALSE;
   }
}
/*
** Function: check input condition of Multiplication
** Param:    rowA, colA, rowB, colB is number of row and column of matrix a and b
*/
int checkMul(int rowA, int colA, int rowB, int colB)
{
    if(colA==rowB)
    {
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}
/*
** Function: Addition matrix
** Param:    row and col is number of row and column of two matrix
**           a, b is input matrix. result of addition save in matrix c
*/
void sumMatrix(float a[100][100], float b[100][100],float c[100][100], int row, int col)
{
    int i,j;
    for(i=0;i<row;i++)
    {
        for(j=0;j<col;j++)
        {
            c[i][j]=a[i][j]+b[i][j];
        }
    }
}
/*
** Function: Multiplication matrix
** Param:    rowA and colA is number of row and column of matrix a
**           a, b is input matrix. result of addition save in matrix c
*/
void mulMatrix(float a[100][100], float b[100][100], float c[100][100], int rowA, int colA,int colB)
{
    int i,j,k;
    for(i=0;i<rowA;i++)
    {
        for(j=0;j<colB;j++)
        {
            c[i][j]=0;
            for(k=0;k<colA;k++)
            {
                c[i][j]=c[i][j]+a[i][k]*b[k][j];
            }
        }
    }
}
int main()
{
    int rowA, colA;
    int rowB, colB;
    int check_s,check_m;/*check condition sum and multiplicaion*/
    int continous;
    float a[100][100];
    float b[100][100];
    float c[100][100];
    float d[100][100];
   do
   {
    printf("Enter row number and column of matrix a: \n");
    scanf("%d%d",&rowA,&colA);
    readMatrix(a,rowA,colA);
    printf("Enter row number and column of matrix b: \n");
    scanf("%d%d",&rowB,&colB);
    readMatrix(b,rowB,colB);
    check_s=checkSum(rowA,colA,rowB,colB);
    if(check_s==FALSE)
    {
        printf("Sum condition wrong.\n");
    }
    else
    {
        printf("Sum condition corect.\n");
        sumMatrix(a,b,c,rowA,colB);
        printf("Sum of two matrix:\n");
        printMatrix(c,rowA,colA);
    }
    check_m=checkMul(rowA,colA,rowB,colB);
    if(check_m==FALSE)
    {
        printf("Multiplication condition wrong.\n");
        if(colB==rowA)/*matrix b* matrix a*/
        {
            printf("But can perform multiplication b*a:\n");
            mulMatrix(b,a,c,rowB,colB,colA);
            printMatrix(c,rowB,colA);
        }
    }
    else
    {
        printf("Multilication condition correct.\n");
        mulMatrix(a,b,d,rowA,colA,colB);
        printf("Result of multiplication:\n");
        printMatrix(d,rowA,colB);
    }
    printf("Are you continue? (1=yes/0=no)\n");
    scanf("%d",&continous);
   }while(continous==TRUE);
}
