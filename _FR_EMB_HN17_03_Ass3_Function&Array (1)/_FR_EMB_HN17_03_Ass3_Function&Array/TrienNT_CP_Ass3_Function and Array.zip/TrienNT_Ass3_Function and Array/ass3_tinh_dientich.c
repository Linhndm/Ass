/*Program finds rectangle area from perimeter and diagonal line
 */
#include<stdio.h>
#include<stdint.h>
#include<math.h>
/***************************************************************************
**Definition
****************************************************************************/
#define TRUE 1
#define FALSE 0
/***************************************************************************
**Prototype
****************************************************************************/
float checkInput(float perm, float diag);
float quadartic(float a, float b,float c, float* x1,float*x2);
float functionArea(float c, float dch);
/**************************************************************************
Variables
****************************************************************************/
/**************************************************************************
Code
****************************************************************************/
/*
**@Function: Check input condition
**@Para:  perm is perimeter of rectangle
**        diag is diagonal line of rectangle
**@Return: FALSE when diagonal line > half of perimeter, perm ordiagonal line <0
           TRUE
*/
float checkInput(float perm, float diag)
{
    if((perm/2)<=diag||perm<0||diag<0)
    {
        return FALSE;/*Input condition wrong */
    }
    else
    {
        return TRUE;
    }
}
/*
**@Function: Slove quadratic equation
**@Para:  a,b,c is coefficent of quadratic equation
**        x1,x2 is root of quadratic equation
**@Return: FALSE when no root
*/
float quadartic(float a, float b, float c, float *x1, float *x2)
{
    float delta =b*b-4*a*c;
    if(delta<0)
    {
        printf("Input wrong. Do not is rectangle \n\n");
        return FALSE;
    }
    else
    {
        if(delta==0)
        {
            *x1=(-b)/(2*a);
        }
        else
        {
            *x1=((-b)-sqrt(delta))/(2*a);
            *x2=((-b)+sqrt(delta))/(2*a);
        }
    }
}
/*
**@Function: Find area of retangle
**@Para:  perm is perimeter of rectangle
**        diag is diagonal line of rectangle
**@Return: area is area of rectangle
*/
float functionArea(float perm, float diag)
{
    float p=perm/2;/*haft of perimeter*/
    float x1,x2;
    float edgeA,edgeB;/*edge of the rectangle*/
    float area;
    float k;
    /*Slove equation: a*a +b*b=c*c & a+b=perm/2*/
    k=quadartic(2,-(2*p),p*p-diag*diag,&x1,&x2);/*find lenght of the edge*/
    if(k==0)/*quadartic equation no root, input do not is rectangle*/
    {
        return FALSE;
    }
    else
    {
        edgeA= x1>x2? x1:x2;/*edge>0*/
        edgeB=p-edgeA;
        area=edgeA*edgeB;
        return area;
    }
}
int main()
{
    float perm;
    float diag;
    float area;
    uint32_t user;/*condition loop*/
    do
    {
        printf("Enter primeter and diagonal line of rectangle: \n");
        printf("Perimeter: ");
        scanf("%f",&perm);
        printf("Diagonal Line: ");
        scanf("%f",&diag);
        uint32_t k=checkInput(perm,diag);/*check condition input*/
        if(k==FALSE)
        {
            printf("\nWRONG INPUT.\n");
            printf("Try again.\n");
            printf("\n");
        }
        else/*true condition*/
        {
            area=functionArea(perm,diag);
            printf("The area of the rentangle: %.2f\n",area);
            user=0;/*end loop*/
        }
        printf("Are you continue? (1=yes/0=no)");
        scanf("%d",&user);
    }while(user==1);
    return 0;
}
