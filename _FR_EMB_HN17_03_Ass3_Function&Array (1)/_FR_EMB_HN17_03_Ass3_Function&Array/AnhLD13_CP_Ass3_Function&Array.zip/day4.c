#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/*******************************************************************************
 * Definitions
 ******************************************************************************/
/* data struture for hold student data */
struct student
{
    int mark;
    char name[64];
    struct student *pNext;  
};
typedef struct student student_t;

/* data structure for student list information */
struct list 
{
    student_t *pHead;
    student_t *pTail;
    int size;
};
typedef struct list list_t;
/*******************************************************************************
 * Prototypes
******************************************************************************/
/* function insert info about one student at top of list */
 void insertTopStudent(char* name, int LenName, int mark, list_t *list);
/* function insert info of one student at bot of list */
void insertBotStudent(char* name, int LenName, int mark, list_t *list);
/* function print detail about students list */
void printListInfo(list_t *list);
/* function find data of student with given name */
void findStudent(char *name, list_t *list);
/* function remove data of a student with given name */
void removeStudent(char *name, list_t *list);
/* function merge list2 at bottom of list1 */
void mergeList(list_t *list1, list_t *list2);
 /*******************************************************************************
 * Variables
 ******************************************************************************/
/* creat two empty student list */
list_t allStudent = { NULL, NULL, 0};
list_t someStudent = {NULL, NULL, 0};

/*******************************************************************************
 * Code
 ******************************************************************************/

void insertTopStudent(char* name, int LenName, int mark, list_t *list)
{
    int i;
    
    /* allocate memory for hold student data */
    student_t *newStudent = (student_t *) malloc(sizeof(student_t));
    newStudent->pNext = NULL;
    memset(newStudent->name, 0, 64);
    
    /* save data of student */
    for (i = 0; i < LenName; i++)
    {
        newStudent->name[i] = name[i];
    }
    newStudent->mark = mark;
    
    /* neu danh sach chua co sinh vien nao, dia chi head va tail cua danh sach 
    bang dia chi sinh vien nay, thong tin sinh vien khong can them gi */
    if ( list->pHead == NULL)
        list->pTail = list->pHead = newStudent;
    /* nguoc lai, sinh vien can luu thong tin danh sach,vi dia chi head se thay doi */
    else
    {    
        newStudent->pNext = list->pHead;
        list->pHead = newStudent;
    }
    (list->size)++;
}

void insertBotStudent(char* name, int LenName, int mark, list_t *list)
{
    int i;
    student_t *newStudent = (student_t *) malloc(sizeof(student_t));
    memset(newStudent->name, 0, 64);
    newStudent->pNext = NULL;
    for (i = 0; i < LenName; i++)
    {
        newStudent->name[i] = name[i];
    }
    newStudent->mark = mark;
    
    /* neu danh sach chua co sinh vien nao, khoi tao dia chi top va tail cua danh sach */
    if (list->pTail == NULL)
    {
        list->pHead = list->pTail = newStudent;
    }
    /* nguoc lai, danh sach can them thong tin dia chi sinh vien sau no, khi do dia chi tail thay doi theo */
    else
    {
        list->pTail = list->pTail->pNext = newStudent;
    }
    (list->size)++;
}


void printListInfo(list_t *list)
{
    student_t *pTmp = list->pHead;
    if (pTmp == NULL)
    {
        printf("Danh sach trong.\n");
    }
    else
        printf("Danh sach gom %d sinh vien nhu sau:\n", list->size);
    /* output information about students from top to bot */
    while(pTmp != NULL)
    {
        printf("Name: %s\tMark: %d\n", pTmp->name, pTmp->mark);
        pTmp = pTmp->pNext;
    }
    
}

void findStudent(char *name, list_t *list)
{
    student_t *temp;
    for (temp = list->pHead; temp != NULL; temp = temp->pNext)
    {
    /* gia su khong co thong tin sinh vien trung ten trong danh sach */
        if (!strcmp(temp->name, name))
        {
            printf("Sinh vien %s co diem so la %d\n", temp->name, temp->mark);
            return ;
        }
    }
    printf("Khong tim thay sinh vien trong danh sach.\n");
    
}


void removeStudent(char *name, list_t *list)
{
    student_t *temp;
    student_t *preTemp = NULL;
    for (temp = list->pHead; temp != NULL; preTemp = temp, temp = temp->pNext)
    {
    /* gia su khong co thong tin sinh vien trung ten trong danh sach */
        if (!strcmp(temp->name, name))
        {
            /* if student at top of list */
            if (temp == list->pHead)  
            {
                list->pHead = temp->pNext;
            }
            else
            {
                preTemp->pNext = temp->pNext;
                /* if student at bot of list */
                if (temp == list->pTail) 
                {
                    list->pTail = preTemp;
                }
            }
            (list->size)--;
            printListInfo(list);
            return ;
        }
    }
    printf("Sinh vien nay chua co trong danh sach.\n");
}

void mergeList(list_t *list1, list_t *list2)
{
    if (list1 == NULL || list2 == NULL)
    {
        printf("Loi do danh sach khong ton tai\n");
    }
    else
    {
        list1->pTail->pNext = list2->pHead;
    }
}
int main(void)
{
    char name[64];
    insertTopStudent("top1", 4, 1, &allStudent);
    insertTopStudent("top2", 4, 1, &allStudent);   
    insertBotStudent("bot1", 4, 1, &allStudent);
    insertBotStudent("bot2", 4, 1, &allStudent); 
    printListInfo(&allStudent);
    removeStudent("bot1", &allStudent);
    removeStudent("bot2", &allStudent);
    insertTopStudent("bot1", 4, 1, &someStudent);
    insertBotStudent("bot2", 4, 1, &someStudent);
    printListInfo(&someStudent);
    mergeList(&allStudent, &someStudent);
    printListInfo(&allStudent);
    findStudent("top1", &allStudent);
    return 0;
}


