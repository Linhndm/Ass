#ifndef _HEADER_FUNCTION_H_
#define _HEADER_FUNCTION_H_

/*******************************************************************************
 * API
 ******************************************************************************/
void input(float *cir, float *dia);
/*!
 * @brief input(&cir,&dia)
 *It has the function of helping users enter the circumference and diagonal length of the rectangle.
 *Check if it satisfies the rectangle.
 *
 * @param cir <Variable stores the circumference of the rectangle>.
 * @param dia <Variable stores the crossover length of the rectangle>.
 *
 * @return <No return value>.
 */
void area(float *cir,float *dia);
/*!
 * @brief area(&cir,&dia) <The function calculates the area of ??the rectangle and prints the result to the screen>
 *
 * @param cir <Variable stores the circumference of the rectangle>.
 * @param dia <Variable stores the crossover length of the rectangle>.
 *
 * @return <No return value>.
 */


#endif /* _HEADER_FUNCTION_H_ */
