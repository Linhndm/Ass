#include <stdio.h>

/*******************************************************************************
 * Prototypes
 ******************************************************************************/
void input(float *cir, float *dia);
void area(float *cir,float *dia);
/*******************************************************************************
 * code
 ******************************************************************************/
void input(float *cir, float *dia)
{
    printf("Enter the cir of the rectangle: ");
    scanf("%f",cir);
    printf("Enter the dia length of the rectangle: ");
    scanf("%f",dia);
    /*Check for conditions that satisfy rectangles based on circumference and diagonal*/
    while(!(((*cir)*(*cir)/8<=(*dia)*(*dia))&&((*cir)*(*cir)/4>(*dia)*(*dia))))
    {
        printf("\nYou entered the wrong data, this is not a rectangle. Please re-enter: ");
        printf("\nEnter the cir of the rectangle: ");
        scanf("%f",cir);
        printf("Enter the dia length of the rectangle: ");
        scanf("%f",dia);
    }
}
void area(float *cir,float *dia)
{
    float area;
    /*Calculate the area based on perimeter and diagona*/
    area=0.5*((*cir)*(*cir)/4-(*dia)*(*dia));
    printf("Rectangular area with cir = %.2f and dia = %.2f is: %.2f",*cir,*dia,area);
}
