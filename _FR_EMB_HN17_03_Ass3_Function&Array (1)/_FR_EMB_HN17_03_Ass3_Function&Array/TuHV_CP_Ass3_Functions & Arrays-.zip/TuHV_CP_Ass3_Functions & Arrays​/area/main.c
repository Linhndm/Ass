#include <stdio.h>
#include <stdlib.h>
#include "function.h"

void main()
{
    float cir,dia;
    input(&cir,&dia);//calling by reference function input
    area(&cir,&dia);//calling by reference function area 
}
