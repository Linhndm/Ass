#include <stdio.h>
#include <stdint.h>
/*******************************************************************************
 * Prototypes
 ******************************************************************************/
int clean_stdin();
int checkKeyFloat(float *input);
int checkKeyInt(int *input);
void outMatrix(int row, int col, float matrix[]);
void initMatrix(int row, int col, float matrix[]);
int checkSum(int rowA, int colA, int rowB, int colB, float matrixA[], float matrixB[]);
int checkMul(int rowA, int colA, int rowB, int colB, float matrixA[], float matrixB[]);
void addMatrix(int rowA, int colA, int rowB, int colB, float matrixA[], float matrixB[]);
void mulMatrix(int rowA, int colA, int rowB, int colB, float matrixA[], float matrixB[]);
 /*******************************************************************************
 * Code
 ******************************************************************************/
int clean_stdin()/*Cleans the memory buffer keyboard*/
{
    while (getchar()!='\n')
    {
        
    }
    return 1;
}
int checkKeyFloat(float *input)
{
    char c;
    /*If the input character is not a real number, enter it again*/
    while(((scanf("%f%c",input,&c)!=2||c!='\n') && clean_stdin()))
    {
        printf("Re-Enter (Float value): ");
    }
    return 1;
}
int checkKeyInt(int *input)
{
    char c;
    /*If the input character is not a integer number, enter it again*/
    while(((scanf("%d%c",input,&c)!=2||c!='\n') && clean_stdin()))
    {
        printf("Re-Enter (Integer value): ");
    }
    return 1;
}
void outMatrix(int row, int col, float matrix[])
{
    int i;
    for(i=0;i<(row)*(col);i++)
    {
        if(0==i%col)
        {
            printf("\n");
        }
        printf("\t%.2f",matrix[i]);
    }
}
void initMatrix(int row, int col, float matrix[])
{
    int i;
    char c;
    for(i=0;i<(row)*(col);i++)
    {
        printf("Enter matrix[%d][%d] = ",i/(col),i%(col));
         checkKeyFloat(&matrix[i]);
    }
    printf("\nYour matrix: \n");
    outMatrix(row,col,matrix);
    printf("\n");
}

int checkSum(int rowA, int colA, int rowB, int colB, float matrixA[], float matrixB[])
{
    int retVal;
    /*cases implementation is allowed to multiply: Two matrices of equal size*/
    if((rowA==rowB)&&(colA==colB))
    {
        printf("\nTwo matrices of equal size, can perform addition!!!");
        retVal=1;
    }
    else
    {
        printf("Sorry, two matrices not of the same size can't perform the addition!!!");
        retVal=0;
    }
    return retVal;
}
int checkMul(int rowA, int colA, int rowB, int colB, float matrixA[], float matrixB[])
{
    int retVal;
    /*cases implementation is allowed to multiply:
    -matrix A or matrix B is a number
    -number of columns of the matrix A = number of rows of the matrix B
    number of columns of the matrix B = number of rows of the matrix A
    */
    if(((1==rowA)&&(1==colA))||((1==rowB)&&(1==colB))||((colA==rowB)||(colB==rowA)))
    {
        printf("\nCan multiply two matrices!!!");
        retVal=1;
    }
    else
    {
        retVal=0;
        printf("\nCan't multiply two matrices!!!");
    }
    return retVal;
}
void addMatrix(int rowA, int colA, int rowB, int colB, float matrixA[], float matrixB[])
{
    int i;
    float addMatrix[rowA*colA];
    for(i=0;i<rowA*colA;i++)
    {
        addMatrix[i]=matrixA[i]+matrixB[i];/*Plus the corresponding positions*/
    }
    printf("\nSum of two matrices: ");
    outMatrix(rowA,colA,addMatrix);/*Print the result of the addition*/
}
void mulMatrix(int rowA, int colA, int rowB, int colB, float matrixA[], float matrixB[])
{
    int i,j,k;
    float mulMatrix[colA*rowB];
    float mulMatrixInvert[colB*rowA];
    if((1==rowA)&&(1==colA))/*The case of matrix A is a number*/
    {
        int i;
        for(i=0;i<rowB*colB;i++)
        {
            mulMatrix[i]=matrixB[i]*matrixA[0];/*Multiplies A with the elements of B*/
        }
        printf("\nMultiplication of two matrices A * B: \n");
        outMatrix(rowB,colB,mulMatrix);/*Print the result of the multiply*/
    }
    
    if((1==rowB)&&(1==colB))/*The case of matrix B is a number*/
    {
        int i;
        for(i=0;i<rowA*colA;i++)
        {
            mulMatrix[i]=matrixA[i]*matrixB[0];/*Multiplies B with the elements of A*/
        }
        printf("\nMultiplicBtion of two mBtrices B * A: \n");
        outMatrix(rowA,colA,mulMatrix);/*Print the result of the multiply*/
    }
    if(colA==rowB)/*if number of columns of A=number of rows of B */
    {
        for(i=0;i<rowA;i++)
        {
            for(j=0;j<colB;j++)
            {
                /*initilalize value is 0*/
                mulMatrix[i*colB+j]=0;
                for(k=0;k<colA;k++)
                {
                    /*multiply the corresponding positions*/
                    mulMatrix[i*colB+j]+=matrixA[colA*i+k]*matrixB[colB*k+j];
                }
            }
        }
        printf("\nMultiplication of two matrices A * B: \n");
        outMatrix(rowA,colB,mulMatrix);
    }
    if(colB==rowA)/*Similar case: colA==rowB*/
    {
        for(i=0;i<rowB;i++)
        {
            for(j=0;j<colA;j++)
            {
                mulMatrixInvert[i*colA+j]=0;
                for(k=0;k<colB;k++)
                {
                    mulMatrixInvert[i*colA+j]+=matrixB[colB*i+k]*matrixA[colA*k+j];
                }
            }
        }
        printf("\nMultiplication of two matrices B * A: \n");
        outMatrix(rowB,colA,mulMatrixInvert);
    }
}
