#ifndef _HEADER_MATRIX_H_
#define _HEADER_MATRIX_H_

/*******************************************************************************
 * API
 ******************************************************************************/
/*!
 * @brief <function cleans the memory buffer keyboard>
 *
 * @param No parameters .
 *
 * @return <Returns 1 after implementation>.
 */
int clean_stdin();

/*!
 * @brief <function Check if the input is real number.>
 *
 * @param *input <The variable name wants to enter the value>.
 *
 * @return <Returns 1 when entering the correct data type>.
 */
int checkKeyFloat(float *input);

/*!
 * @brief <function Check if the input is integer number.>
 *
 * @param *input <The variable name wants to enter the value>.
 *
 * @return <Returns 1 when entering the correct data type>.
 */
int checkKeyInt(int *input);

/*!
 * @brief <print out a matrix>
 *
 * @param row <number of rows of matrix>.
 * @param col <number of columns of matrix>.
 * @param matrix <the matrix>.
 *
 * @return <no return value>.
 */
void outMatrix(int row, int col, float matrix[]);

/*!
 * @brief <function allows the user to enter the matrix>
 *
 * @param row <number of rows of matrix>.
 * @param col <number of columns of matrix>.
 * @param matrix <the matrix>.
 *
 * @return <no return value>.
 */
void initMatrix(int row, int col, float matrix[]);

/*!
 * @brief <Check if two implementation matrices are allowed to add>
 *
 * @param row <number of rows of matrix A>.
 * @param col <number of columns of matrix A>.
 * @param matrix <the matrix A>.
 * @param row <number of rows of matrix B>.
 * @param col <number of columns of matrix B>.
 * @param matrix <the matrix B>.
 *
 * @return <return 1: Additions can be performed>.
 * @return <return 0: Additions can't be performed>.       
 */
int checkSum(int rowA, int colA, int rowB, int colB, float matrixA[], float matrixB[]);

/*!
 * @brief <Check if two implementation matrices are allowed to multiplication>
 *
 * @param row <number of rows of matrix A>.
 * @param col <number of columns of matrix A>.
 * @param matrix <the matrix A>.
 * @param row <number of rows of matrix B>.
 * @param col <number of columns of matrix B>.
 * @param matrix <the matrix B>.
 *
 * @return <return 1: multiplications can be performed>.
 * @return <return 0: multiplications can't be performed>.
 */
int checkMul(int rowA, int colA, int rowB, int colB, float matrixA[], float matrixB[]);

/*!
 * @brief <Performs the addition of two matrices>
 *
 * @param row <number of rows of matrix A>.
 * @param col <number of columns of matrix A>.
 * @param matrix <the matrix A>.
 * @param row <number of rows of matrix B>.
 * @param col <number of columns of matrix B>.
 * @param matrix <the matrix B>.
 *
 * @return <no return value>.
 */
void addMatrix(int rowA, int colA, int rowB, int colB, float matrixA[], float matrixB[]);

/*!
 * @brief <Performs the multiplcation of two matrices>
 *
 * @param row <number of rows of matrix A>.
 * @param col <number of columns of matrix A>.
 * @param matrix <the matrix A>.
 * @param row <number of rows of matrix B>.
 * @param col <number of columns of matrix B>.
 * @param matrix <the matrix B>.
 *
 * @return <no return value>.
 */
void mulMatrix(int rowA, int colA, int rowB, int colB, float matrixA[], float matrixB[]);
#endif /* _HEADER_MATRIX_H_ */
