#include <stdio.h>
#include <stdlib.h>
#include "matrix.h"
#define n 50
void main()
{
    int rowA,colA,i;
    int rowB,colB;
    float matrixA[n];
    float matrixB[n];
    int command=1;
    while(command!=0)/*Consider whether to continue with the program*/
    {
        printf("Enter the numbers of rows and columns");
        printf("\nNumbers of rows: ");
        checkKeyInt(&rowA);/*calling function check keyboard input integer number*/
        printf("Numbers of columns: ");
        checkKeyInt(&colA);/*calling function check keyboard input integer number*/
        while(!(rowA>0&&colA>0))/*Re-enter if entered wrong*/
        {
            printf("You entered the wrong data, please re-enter.");
            printf("\nNumbers of rows: ");
            checkKeyInt(&rowA);/*calling function check keyboard input integer number*/
            printf("Numbers of columns: ");
            checkKeyInt(&colA);/*calling function check keyboard input integer number*/
        }
        initMatrix(rowA,colA,matrixA);/*function allows the user to enter the matrix*/
        printf("Enter the numbers of rows and columns");
        printf("\nNumbers of rows: ");
        checkKeyInt(&rowB);
        printf("Numbers of columns: ");
        checkKeyInt(&colB);
        while(!(rowB>0&&colB>0))
        {
            printf("You entered the wrong data, please re-enter.");
            printf("\nNumbers of rows: ");
            checkKeyInt(&rowB);
            printf("Numbers of columns: ");
            checkKeyInt(&colB);
        }
        initMatrix(rowB,colB,matrixB);
        if(checkSum(rowA,colA,rowB,colB,matrixA,matrixB))/*Check if two implementation matrices are allowed to add*/
        {
            addMatrix(rowA,colA,rowB,colB,matrixA,matrixB);
        }
        if(checkMul(rowA,colA,rowB,colB,matrixA,matrixB))/*Check if two implementation matrices are allowed to multiplication*/
        {
            mulMatrix(rowA,colA,rowB,colB,matrixA,matrixB);
        }
        printf("\nDo you want continue?\tENTER (Yes=1/No=0): ");
        checkKeyInt(&command);
    }
}

