#include <stdio.h>
#include <math.h>
#include <stdint.h>
/*******************************
*functions
*******************************/

float rectangularArea( float p,float c)
{
    /* p:Perimeter of the Rectangular
    **c:diagonal line of the Rectangular*/
    if(p<=0 || c <=0)
    {
        printf("INPUT WRONG! Perimeter and diagonal line must be greater than 0. ");
        return 0;
    }
    if(p/2<=c)
    {
        printf("INPUT WRONG!The Perimeter must be twice the diagonal line. \n");
        return 0;
    }
    float edge1,edge2,deta;
    /* edge1*edge1+edge2*edge2=c*c
	   edge1+edge2=p/2
	=> 2x -p*x+((p*p)/4-c*c)=0 
	   x1=edge1
       x2=edge2******************/
    deta=p*p - 8*((p*p/4)-(c*c));
    printf("deta=%.2f \n",deta);
    if(deta==0)
    {
        edge1=edge2=p/4;
    }
    if(deta>0)
    {
        edge1=(p+sqrt(deta))/4;
        edge2=(p-sqrt(deta))/4;
    }
    if(deta<0)
    {
        printf("INPUT WRONG\n");
        return 0;
    }
    printf("edge 1 %.2f\n",edge1);
    printf("edge 2 %.2f\n",edge2);
    return edge1*edge2;
}


/*******************************
*main function
*******************************/
main()
{
    float p=0,c=0,s=0;
    while(s==0)
    {
        printf("Enter perimeter of the rectangular: ");
        scanf("%f",&p);
        printf("Enter diagonal line of the retangular: ");
        scanf("%f",&c);
        s=rectangularArea(p,c);
    }
    printf("Area of the Rectangular is :%.2f",s);
}

