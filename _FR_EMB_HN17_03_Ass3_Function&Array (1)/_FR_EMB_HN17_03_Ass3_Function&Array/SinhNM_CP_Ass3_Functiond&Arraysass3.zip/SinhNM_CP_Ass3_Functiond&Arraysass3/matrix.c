#include <stdio.h>
#include <math.h>
#include <stdint.h>
/**********************************
*functions
**********************************/

/*Import matrix from keyboard*/
void importMatrix(uint32_t A[],uint32_t row,uint32_t column)
{
/*row:the row value of the matrix A
  column:the column value � the matrix A*/
    uint32_t i,j,cnt=0;/*cnt:variable index of the matrix A*/
    for(i=0;i<row;i++)
    {
        for(j=0;j<column;j++)
        {
        	  printf("a[%d][%d]=",i,j);
        	  scanf("%d",&A[cnt]);
              cnt++;
        }
    }
}
void exportMatrix(uint32_t A[],uint32_t row,uint32_t column)
{
/*row:the row value of the matrix A
  column:the column value � the matrix A*/
    uint32_t i,j,cnt=0;/*cnt:variable index of the matrix A*/
    for(i=0;i<row;i++)
    {
        for(j=0;j<column;j++)
        {
            printf("a[%d][%d]=%d",i,j,A[cnt]);
            printf("   ");
            cnt++;
        }
        printf("\n");
    }  
}
uint8_t addMatrix(uint32_t firstMatrix[],uint32_t rowFirst,uint32_t columnFirst,uint32_t secondMatrix[],uint32_t rowSecond,uint32_t columnSecond,uint32_t sum[])
{
/*sum[]:sum of firstMatrix[] and secondMatrix*/
    if(rowFirst!=rowSecond || columnFirst != columnSecond)
    {
        /* Can't add these matrices, because they're not the same size*/
        printf("row different column,not add!");
        return 0;
    }
    else
    {
        uint32_t n=rowFirst*columnFirst,i;/*Array sum[] have n element*/
        for(i=0;i<n;i++)
        {
            sum[i]=firstMatrix[i]+secondMatrix[i];
        }
         return 1;
    }
}

uint8_t multiplyMatrices(uint32_t firstMatrix[],uint32_t rowFirst,uint32_t columnFirst,uint32_t secondMatrix[],uint32_t rowSecond,uint32_t columnSecond,uint32_t mult[])
{
    uint8_t select;
    if(columnFirst!=rowSecond)
    {
        printf("Not possible to multiply the FirstMatrix by the SecondMatrix !\n");
        if(columnSecond==rowFirst)
        {
            printf("Second Matrix can be multiplied by First Matrix\n");
            printf("Enter 1 if you want Second Matrix * First Matrix\n");
            printf("Enter !=1 if you want exit \n");
            scanf("%d",&select);
            if(select==1)
            {
                /* function recursion */
                multiplyMatrices(secondMatrix,rowSecond,columnSecond,firstMatrix,rowFirst,columnFirst,mult);
                return 2;
            }
            else
            {
                return 0;
            }
        }
        else
        {
            return 0;
        }
    }
    else
    {
        /*The naive algorithm*/
        uint32_t i,j,k,cnt=0;
        for(i=0;i<rowFirst;i++)
        {
            for(j=0;j<columnSecond;j++)
            {
                mult[cnt]=0;
                for(k=0;k<columnFirst;k++)
                {
                    mult[cnt]=mult[cnt]+firstMatrix[i*columnFirst+k]*secondMatrix[k*columnSecond+j];
                }
                cnt++;
            }
        }
        return 1;
    }
}
/**********************************
*main function
**********************************/
main()
{
    uint32_t rowFirst=0,columnFirst=0,rowSecond=0,columnSecond=0,firstMatrix[100],secondMatrix[100],add[100],mult[100],select,a,m,s;
    do
    {
        do
        {
           /*Enter First Matrix*/
            printf("Enter the row value of First Matrix : ");
            scanf("%d",&rowFirst);
            printf("Enter the column value of First Matrix : ");
            scanf("%d",&columnFirst);  
            if(rowFirst<0 || columnFirst<0)
            {
                printf("ENTER WRONG! ");
            }
        }
        while(rowFirst<0 || columnFirst <0);
        importMatrix(firstMatrix,rowFirst,columnFirst);
        printf("First Matrix:\n");
        exportMatrix(firstMatrix,rowFirst,columnFirst);
        do
        {
             /*Enter Second Matrix*/
            printf("Enter the row value of Second Matrix: ");
            scanf("%d",&rowSecond);
            printf("Enter the column value of Second Matrix : ");
            scanf("%d",&columnSecond);  
            if(rowSecond<0 || columnSecond<0)
            {
                printf("ENTER WRONG! ");
            }
        }
        while(rowSecond<0 || columnSecond<0);
        importMatrix(secondMatrix,rowSecond,columnSecond);
        printf("Second Matrix:\n");
        exportMatrix(secondMatrix,rowSecond,columnSecond);
        do
        {
            /*Select add or multiply*/
            printf("Enter 0 if you want multiply Matrices.\n");
            printf("Enter 1 if you want add Matrices.\n");
            scanf("%d",&select);
            if(select<0 || select>1)
            {
                printf("ENTR WRONG!\n");
            }
        }
        while(select<0 || select>1);
        if(select==0)
        {
            m=multiplyMatrices(firstMatrix,rowFirst,columnFirst,secondMatrix,rowSecond,columnSecond,mult);
            if(m==1)
            {
               /*m=1 FirstMatrix can multuply SecondMatrix*/
                printf("FirstMatrix * SecondMatrix=\n");
                exportMatrix(mult,rowFirst,columnSecond);
            }
            if(m==2)
            {
                /*m=2 FirstMatrix can multuply SecondMatrix,but econdMatrix can multuply FirstMatrix*/
                printf("SecondMatrix * FirstMatrix=\n");
                exportMatrix(mult,rowFirst,columnSecond);
            } 
        }
        if(select==1)
        {
            a=addMatrix(firstMatrix,rowFirst,columnFirst,secondMatrix,rowSecond,columnSecond,add);
            if(a==1)
            {
                printf("FirstMatrix + SecondMatrix=\n");
                exportMatrix(add,rowFirst,columnSecond);
            }
        }
        printf("Enter 1 if you want to do it again\n");
        printf("Enter 0 if you do not want to do it again\n");
        scanf("%d",&s); 
    }
    while(s==1);
}


