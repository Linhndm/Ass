/***********************************************************************************************************************
 *Author: Linhndm
 *Date Modifed: 15/06/2017 1:50PM
 *Name: Ass3.1_Calculator_area_Rectangle
 **********************************************************************************************************************/

1> This program help You calculator area of rectangle.
3> Don't use pointer.
2> Use two function


/Function1*************************************************************************************************************/

/*
Function : void Input
    @brief: Enter Parameter and Diagonal line of Rectangle from keyboard.
            Check condition of Rectangle
    @param:
                + check : check condition of Parameter and Diagonal line
                + g_par : Parameter of rectangle
                + g_dir : Diagonal line of Rectangle
*/
/Function2*************************************************************************************************************/
/*
Function : float Area (float par, float dia)
    @brief: Input Parameter and Diagonal line of Rectangle.
    @param:
                + S : Area of Rectangle
                + par : Parameter of rectangle
                + dir : Diagonal line of Rectangle
*/
