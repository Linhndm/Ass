/***********************************************************************************************************************
 *Author: Linhndm
 *Date Modifed: 15/06/2017 1:50PM
 *Name: Ass3.1_Calculator_area_Rectangle
 **********************************************************************************************************************/

1> This program help You calculator:
	+ Check condition of matrixes for multiply and add matrixes.
	+ Calculator multiply and add two matrixes.
2> Don't use pointer.
3> Use global variables:

/*
 * Matrix1, Matrix2: Input Matrixes
 * Matrix 3: Result of Multiply Matrixes
 * Matrix 4: Result of Add Matrixes
 */


4> Use seven functions


/Function1*************************************************************************************************************/
/*
Function : int check(float row, float columns)
    @brief: Check matrix with rows and colomns. If rows or columns is a Positive or Integer Fun will return 0;
                + row: rows of matrix
                + col: columns of matrix
    @return: 
                + True or False
*/
/Function2*************************************************************************************************************/
/*
Function : void ReadMatrix()
    @brief: Input two matrixes
    @param:
                + i,j : count value
*/
/Function3*************************************************************************************************************/
/*
Function : int isMulMatrix()
    @brief: Check condition for Multiply Matrixes
    @return:
                + True: If Cannot Multiply two matrixes
                + False: If reverse

*/
/Function4*************************************************************************************************************/
/*
Function : void multiply()
    @brief: Caculator to multiply matrixes
    @param:
                + i,j : count value
*/
/Function5*************************************************************************************************************/
/*
Function : isAddMatrix()
    @brief: Check condition for Add Matrixes
    @return:
                + True: If Cannot Add two matrixes
                + False: If reverse

*/
/Function6*************************************************************************************************************/
/*
Function : void Add()
    @brief: Calculator to Add two matrixes
    @param:
                + i,j : count value
*/
/Function7*************************************************************************************************************/
/*
Function : void PrintMatrix(float matrix[N_MAX][M_MAX])
    @brief: Print matrix to screen
    @param:
               + i, j: count value.
*/